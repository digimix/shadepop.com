<?php get_template_part('templates/page', 'header'); ?>
<?php woocommerce_content(); ?>