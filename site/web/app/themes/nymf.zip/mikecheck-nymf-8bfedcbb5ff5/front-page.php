<?php
/**
 * Frontpage
 */
 use Roots\Sage\Extras;

 while (have_posts()) : the_post();
$cta_headline = get_post_meta($post->ID, '_nda_cta_headline', 1);
$cta_copy = get_post_meta($post->ID, '_nda_cta_copy', 1);
$cta_btn = get_post_meta($post->ID, '_nda_cta_btn', 1);
$cta_url = get_post_meta($post->ID, '_nda_cta_url', 1);
$featured_listings = get_post_meta($post->ID, '_nda_featured_prop_listings', 1);
$featured_listings_commalist = implode(', ', $featured_listings);
?>


<div class="gallery gallery-home" data-flickity-options='{ "freeScroll": true, "wrapAround": true,
"contain": true }'>
<?php

$args = array( 'posts_per_page' => 5, 'include' => $featured_listings_commalist );
$myposts = get_posts( $args );
foreach ( $myposts as $post ) : setup_postdata( $post );

	get_template_part('templates/content', 'slide');

endforeach;
//wp_reset_postdata();

?>
</div>
<section class="parallax nyc-east text-center">
	<div class="container">
		<ul class="col-4 text-center caps" style="padding-top: 70px;font-size: 2em;">
			<li>Manhattan</li>
			<li>Brooklyn</li>
			<li>Queens</li>
			<li>Bronx</li>
		</ul>
	</div>
</section>

<section>
	<div class="container">
		<h3 class="text-center caps" style="margin-bottom: 60px;">Latest Sales Reports</h3>
		<ul class="sales-report col-4">
		<?php

		$args = array( 'posts_per_page' => 4, 'post_type' => 'dlm_download', 'dlm_download_category' => 'reports' );

		$myposts = get_posts( $args );
		foreach ( $myposts as $post ) : setup_postdata( $post ); global $dlm_download; ?>

			<li>
				<a class="download-link" title="<?php $dlm_download->the_title(); if ( $dlm_download->has_version_number() ) printf( __( 'Version %s', 'download_monitor' ), $dlm_download->get_the_version_number() ); ?>" href="<?php $dlm_download->the_download_link(); ?>" rel="nofollow">
					<figure>
						<?php //the_post_thumbnail('large', array('class'=>'img-responsive')); ?>
						<img src="<?= Extras\featured_url(['353', '99999']); ?>" class="img-responsive">
					</figure>
				</a>
			</li>
		<?php endforeach;
		wp_reset_postdata();

		?>
		</ul>
	</div>
</section>




	<?php //get_template_part('templates/page', 'header'); ?>
	<?php //get_template_part('templates/content', 'page');
	$post_id = $post->ID;
	$stats = get_post_meta($post->ID, '_nda_stats_stat', 1);
	?>

<section class="parallax bkb-area">
	<div class="summary container">
		<h3 class=" text-center">
			<?= get_post_meta($post_id, '_nda_stats_title', 1); ?>
		</h3>
		<p class="description" style="margin-top: 0;margin-bottom: 70px;"><?= get_post_meta($post_id, '_nda_stats_copy', 1); ?></p>
	</div>
	<div class="summary container" <?php if ($stats != '') {echo 'style="border:0;padding:0;font-style:normal;"';}?>>
		<div class="container-sm-height" class="clearfix">
			<div class="row-sm-height">
				<?php
				$i=0; foreach ( (array) $stats as $key => $stat ) {
				    // $img = $title = $desc = $caption = '';

				    if ( isset( $stat['s_title'] ) )
				        $title = esc_html( $stat['s_title'] );

				    if ( isset( $stat['s_copy'] ) )
				        $desc = wpautop( $stat['s_copy'] );

				    if ( isset( $stat['s_ico'] ) )
				        $icon = $stat['s_ico'];

				        $i++;
					?>
					<div class="stat col-sm-height col-sm-4 border center <?= ($i%2 ? 'odd':'even'); ?>">

						<header>
							<div class="num-ico"><?= $icon; ?></div>
							<h4><?= $title;?></h4>
							<!-- <p class="subtitle"><?= $days;?></p> -->
							<!-- <i class="fa <?= $icon; ?>"></i> -->
						</header>
						<p><?= $desc; ?></p>

					</div>
				<?php
				} ?>
			</div>
		</div>
	</div>
</section>
<?php endwhile; ?>

	<?php get_template_part('templates/content-agents'); ?>


<section class="shaded-brand text-center light-text">
	<?php if ($cta_headline !=='') { ?>
	<h2 style="margin-bottom: 10px;"><?= $cta_headline; ?> </h2>
	<?php } if ($cta_copy !=='') { ?>
	<h4 class="beta" style="margin-bottom: 10px;"><?= $cta_copy; ?> </h4>
	<?php } if ($cta_url !=='') { ?>
	<a class="btn btn-outline btn-white delta" title="" href="<?= $cta_url; ?>"><?= $cta_btn; ?> <i class="arrrows">r</i></a>
	<?php } ?>

</section>
