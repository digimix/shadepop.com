<footer class="content-info" role="contentinfo">
  <div class="container">
	  <div class="row">
		  <div class="col-12 center">
			  <img src="/app/uploads/2015/06/marcus-millichap-logo.png" class"img-repsonsive aligncenter" width="300" style="margin-bottom: 20px;">
			  <p class="textalign-center">© 2015 Peter Von Der Ahe  •  Marcus & Millichap  •  270 Madison Avenue  •  7th Floor  •  New York City, NY 10016  •  Phone 212.430.5114  •  <a href="/privacy" title"NewYorkMultifamily.com Privacy Polciy">Privacy Policy</a></p>
			  <p style="font-size: 82%;">The representations contained on this internet page are provided based on information deemed reliable. However, the same has not been independently verified. Principals are advised to conduct a thorough due diligence for any potential transaction. Marcus & Millichap Real Estate Investment Services name and logo are used herein for information purposes only. Made by Digimix <a href="http://digimix.us">NYC Web Development</a>. </p>
		  </div>
	  </div>
    <?php dynamic_sidebar('sidebar-footer'); ?>

  </div>
</footer>
