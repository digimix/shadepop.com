<?php
	 use Roots\Sage\Extras;
	$subtitle = get_post_meta( $post->ID, '_nda_subtitle', true );
	$price = get_post_meta( $post->ID, '_nda_price', true );
	$price2 = preg_replace('/[\$,]/', '', $price);
	$price2 = floatval($price2);
	$price = preg_replace('~\.0+$~','',$price);
	$gross_sf = get_post_meta( $post->ID, '_nda_gross_sf', true );
	$units = get_post_meta( $post->ID, '_nda_units', true );
	$neighborhood = get_post_meta( $post->ID, '_nda_neighborhood', true );
	$neighborhood = preg_replace('/,.*/s', '', $neighborhood);
	$buildingtype = get_post_meta( $post->ID, '_nda_subtype', true );
	$title = get_the_title();
	$title = preg_replace('/Avenue,/', 'Avenue', $title);
	$title = preg_replace('/Avenue/', 'Ave, ', $title);
	$title = preg_replace('/Street,/', 'Street', $title);
	$title = preg_replace('/Street/', 'St, ', $title);
	$title = preg_replace('/Place,/', 'Place', $title);
	$title = preg_replace('/Place/', 'Place, ', $title);
	$title = preg_replace('/Blvd,/', 'Blvd', $title);
	$title = preg_replace('/Blvd/', 'Blvd, ', $title);
	$title = preg_replace('/Parkway,/', 'Parkway', $title);
	$title = preg_replace('/Parkway/', 'Parkway, ', $title);
	// $title = preg_replace('/Avenue/', '$1,', $title);
	// $title = preg_replace('/Avenue,\b/i','Avenue', $title);
	// $title = preg_replace('/Avenue\b/i','Ave', $title);
	// $title = preg_replace('/Street\b/i','St', $title);
	// $title = preg_replace('/and\b/i','&', $title);

	if (has_post_thumbnail()) {
		//$thumb_id = get_post_thumbnail_id();
		//$thumb_url = wp_get_attachment_image_src($thumb_id,'original', true);
		//$slide_img = $thumb_url[0];
		$slide_img = Extras\featured_url(['1600', '1012']);
		//echo '<img class="h100 w100 lazy" src="'.$thumb_url[0].' data-original="'.$thumb_url[0].'">';
		// echo get_the_post_thumbnail('thumbnail', array('class'=>'h100 w100'));
	} else {
		$slide_img = '<img class="h100 w100 lazy" data-src="/wp-content/uploads/2015/01/no-img.png">';
	}
?>

<figure class="gallery-cell" style="background-image:url(<?= $slide_img; ?>);">
	<a href="<?php the_permalink(); ?>">
		<figcaption>
			<div class="container">
				<div style="padding-left: 15px;padding-right: 15px;">
					<h2><?= $subtitle; ?></h2>
					<h3 class="serif" style="padding-top: 0;"><?= $title; ?></h3>
					<?php if ($buildingtype || $neighborhood !='') {?>
						<h4 class="subtitle epsilon" style="margin-top: 0;">
							<?php
							if ($buildingtype !='') {
								echo $buildingtype . ', ';
							}
							if ($neighborhood !='') {
								echo $neighborhood;
							}  ?>
						</h4>
					<?php } ?>
				</div>
			</div>
			<div class="row">
				<div class="stats-bar col-sm-12">
					<div class="container">
						<div class="col-sm-2 stats hidden-xs">
							<?php if ($price > 0) { echo '$' . $price;} else { echo 'See Listing Agent';} echo '<small class="clearfix">Price</small>'; ?>
						</div>
						<?php ?>
						<div class=" col-sm-2 stats hidden-xs">
							<?php if ($units !='') {echo $units . '<small class="clearfix">Units</small>'; } ?>
						</div>

						<div class=" col-sm-2 stats hidden-xs">
							<?php if ($gross_sf !='') { echo $gross_sf . '<small class="clearfix">Gross SqFt</small>'; } ?>
						</div>

						        <div class="col-sm-6 stats stats-available">
							<?php
							if ( in_category( 'under-contract' )) {
								echo '<a class="under-contract caps btn btn-default" href="' . get_permalink() . '"> <i class="fa fa-circle"></i> Under Contract</a>';
							}
							elseif ( in_category( 'on-market' )) {
								echo '<a class="available caps btn btn-default" href=" ' . get_permalink() .'"><i class="fa fa-circle"></i> Available</a>';
							} elseif ( in_category( 'recent-sales' )) {
								echo '<a class="sold caps btn btn-default" href="' . get_permalink() . '"><i class="fa fa-circle"></i> Sold</a>'; 
							} else {
								// etc.
							}
							?>
						</div>
					</div>
				</div>
			</div>


		</figcaption>
	</a>

</figure>
