<?php use Roots\Sage\Titles;
	$subtitle = get_post_meta(get_the_id(), '_nda_subtitle', true); ?>

<div class="page-header">
  <h1><?= Titles\title(); ?></h1>
  <?php if ( is_category() ) {echo '<p class="subtitle">Updated in Real Time</p>'; } else if ($subtitle !='') {echo '<p class="subtitle">'.$subtitle.'</p>';} ?>
</div>
