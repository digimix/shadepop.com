<li class="shaded-light" style="padding-bottom: 30px;">
<article <?php post_class(); ?>>
	<header>
		<h2 class="entry-title caps"><?php the_title(); ?></h2>
		<?php if (get_post_type() === 'post') { get_template_part('templates/entry-meta'); } ?>
	</header>

	<div class="entry-summary">
		<?php the_content(); ?>
	</div>

</article>
</li>