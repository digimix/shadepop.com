<?php

use Roots\Sage\Extras;


if (is_page()) {
	$agents = get_post_meta(get_the_id(), '_nda_featured_agents', 1);
	$cols = 'col-3';
} else {
	$agents = get_post_meta(get_the_id(), '_nda_listing_brokers', 1);
	$cols = 'col-3';
}

if( '' !== $agents ) { ?>
<section class="shaded-light">
	<div class="mobile-wrapper">
		<ul class="featured-agents <?php echo $cols; ?>">
		<?php

		foreach ( $agents as $key => $agent) {

			$user_info = get_userdata($agent); ?>
			<li>
				<figure class="cols">

					<div class="image-wrap">
						<a href="<?= get_author_posts_url( $agent ); ?>">
							<?php
							$avatar_url = $user_info->_nda_user_avatar;
							$avatar_id = attachment_url_to_postid($avatar_url);

							$avatar =  Extras\featured_url_by_id($avatar_id, 'square-medium');
							?>
						<img class="avatar" src="<?= $avatar;?>">

						</a>
					</div>
					<figcaption>
						<p class="agent">
							<?= '<a title="Link to '. $user_info->display_name.'&#39;s profile" href="'. get_author_posts_url( $agent ).'" target="_blank">' . $user_info->first_name . ' '  . $user_info->last_name .'</a>'; ?>
						</p>
						<?php
						if (get_user_meta($agent, '_nda_work_phone', true)) {
							echo '<p class="phone"><i class="fa fa-fw fa-phone"></i> ' . get_user_meta($agent, '_nda_work_phone', true) . '</p>';
						}
						if ($user_info->user_email) {
							echo '<p class="email"><i class="fa fa-fw fa-envelope"></i> <a title="Send an email to '.$user_info->display_name.'" href="mailto:'. $user_info->user_email . '?Subject=Inquiry / newyorkmultifamily.com " target="_top">' . $user_info->user_email . '</a></p>';
						}
						?>
					</figcaption>
				</figure>
			</li>
			<?php
		}
		?>
		</ul>
	</div>
</section>

<?php } ?>