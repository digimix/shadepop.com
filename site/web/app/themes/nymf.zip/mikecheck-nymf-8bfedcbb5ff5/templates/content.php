<?php
$price = get_post_meta( $post->ID, '_nda_price', true );
$price2 = preg_replace('/[\$,]/', '', $price);
$price2 = floatval($price2); $price = preg_replace('~\.0+$~','',$price);
?>

<li class="visible" data-price="<?php echo $price2; ?>">
<article <?php post_class(); ?>>
	<a href="<?php the_permalink(); ?>">
		<figure>
			<?php
				if (has_post_thumbnail()) {
					$thumb_id = get_post_thumbnail_id();
					$thumb_url = wp_get_attachment_image_src($thumb_id,'listing-archive', true);
					echo '<img class="h100 w100 lazy" src="'. get_stylesheet_directory_uri() .'/assets/images/default-listing.jpg" data-original="'.$thumb_url[0].'">';
					// echo get_the_post_thumbnail('thumbnail', array('class'=>'h100 w100'));
				} else {
					echo '<img class="h100 w100 lazy" src="'. get_stylesheet_directory_uri() .'/assets/images/default-listing.jpg" data-src="'. get_stylesheet_directory_uri() .'/assets/images/default-listing.jpg">';
				}
			?>
			<figcaption class="serif hidden">
				<?php
					$title = get_the_title();
					$title = preg_replace('/Avenue,/', 'Avenue', $title);
					$title = preg_replace('/Avenue/', 'Ave,<br/>', $title);
					$title = preg_replace('/Street,/', 'Street', $title);
					$title = preg_replace('/Street/', 'St,<br/>', $title);
					$title = preg_replace('/Place,/', 'Place', $title);
					$title = preg_replace('/Place/', 'Place,<br/>', $title);
					$title = preg_replace('/Blvd,/', 'Blvd', $title);
					$title = preg_replace('/Blvd/', 'Blvd,<br/>', $title);
					$title = preg_replace('/Parkway,/', 'Parkway', $title);
					$title = preg_replace('/Parkway/', 'Parkway,<br/>', $title);
					// $title = preg_replace('/Avenue/', '$1,', $title);
					// $title = preg_replace('/Avenue,\b/i','Avenue', $title);
					// $title = preg_replace('/Avenue\b/i','Ave', $title);
					// $title = preg_replace('/Street\b/i','St', $title);
					// $title = preg_replace('/and\b/i','&', $title);
				?>
				<h3><?php echo $title; ?></h3>

					<?php
					if (has_category(19,$post->ID)) {
						echo '<h4 class="subtitle m0 epsilon text-light" style="padding-bottom:15px;">Under Contract</h4>';
					} else if (has_category(29,$post->ID)) {
						echo '<h4 class="subtitle m0 epsilon text-light" style="padding-bottom:15px;">Contract Pending</h4>';
					}
					?>


				<p><em><?php if ($price > 0) { echo '$' . $price;} else { echo 'See Listing Agent';} ?></em></p>
			</figcaption>
		</figure>
	</a>
</article>
</li>