<?php
	use Roots\Sage\Extras;

	 while (have_posts()) : the_post();
	$neighborhood = get_post_meta( $post->ID, '_nda_neighborhood', true );
	$neighborhood = preg_replace('/,.*/s', '', $neighborhood);
	$gross_sf = get_post_meta( $post->ID, '_nda_gross_sf', true );
	$units = get_post_meta( $post->ID, '_nda_units', true );
	$subtype = get_post_meta( $post->ID, '_nda_subtype', true );
	$buildingtype = get_post_meta( $post->ID, '_nda_subtype', true );
	$dlm_id = get_post_meta($post->ID, '_nda_marketing_dlm', 1);
	$price = get_post_meta( $post->ID, '_nda_price', true );
	$price = preg_replace('~\.0+$~','',$price);
	$gross_rent = get_post_meta( $post->ID, '_nda_gross_rent', true );
	$gross_rent = preg_replace('~\.0+$~','',$gross_rent);
	$noi = get_post_meta( $post->ID, '_nda_noi', true );
	$noi = preg_replace('~\.0+$~','',$noi);
	$cap_rate_current = get_post_meta( $post->ID, '_nda_cap_rate_current', true );
	$cap_rate_proforma = get_post_meta( $post->ID, '_nda_cap_rate_proforma', true );
	$grm_current = get_post_meta( $post->ID, '_nda_grm_current', true );
	$grm_proforma = get_post_meta( $post->ID, '_nda_grm_proforma', true );
	$ppsft = get_post_meta( $post->ID, '_nda_ppsft', true );
	$ppsft = preg_replace('~\.0+$~','',$ppsft);
	$ppu = get_post_meta( $post->ID, '_nda_ppu', true );
	$ppu = preg_replace('~\.0+$~','',$ppu);
	$building_size = get_post_meta( $post->ID, '_nda_building_size', true );
	$lot_size = get_post_meta( $post->ID, '_nda_lot_size', true );
	$year_built = get_post_meta( $post->ID, '_nda_year_built', true );
	$total_buildable_sqft = get_post_meta( $post->ID, '_nda_total_buildable_sqft', true );
	$price_per_buildable_sqft = get_post_meta( $post->ID, '_nda_price_per_buildable_sqft', true );
	$price_per_buildable_sqft = preg_replace('~\.0+$~','',$price_per_buildable_sqft);
	$far = get_post_meta( $post->ID, '_nda_far', true );
	$approved_plans = get_post_meta( $post->ID, '_nda_approved_plans', true );
	$existing_finance = get_post_meta( $post->ID, '_nda_existing_finance', true );
	$status = get_post_meta( $post->ID, '_nda_status', true );
	$bid_deadline = get_post_meta( $post->ID, '_nda_bid_deadline', true );
	$renovated = get_post_meta( $post->ID, '_nda_renovated', true );
	$list_to_close_ratio = get_post_meta( $post->ID, '_nda_list_to_close_ratio', true );
	$number_of_offers = get_post_meta( $post->ID, '_nda_number_of_offers', true );

	$diligence = get_post_meta( $post->ID, '_nda_diligence', true );
	$mpack = get_post_meta( $post->ID, '_nda_mpack', true );
	$financing = get_post_meta( $post->ID, '_nda_financing', true );
	$offer = get_post_meta( $post->ID, '_nda_offer', true );

	$nda_brokers_json = get_post_meta( get_the_ID(), '_nda_brokers', true );
	$nda_brokers = json_decode($nda_brokers_json);


?>
	<article <?php post_class(); ?>>
		<header class="col-sm-12" style="padding:0;">
			<a href="https://www.google.com/maps/preview?q=<?= urlencode(get_the_title()); ?>">
				<div class="mapmarker">
				    <i class="fa fa-map-marker"></i>
				</div>
			</a>
			<div class="center-container is-table" style="height: 60px;width:70%;padding-left: 15px;">
				<div class="table-cell">
					<div class="center-block">
						<?php
							$title = get_the_title();
							$title = preg_replace('/Avenue,/', 'Avenue', $title);
							$title = preg_replace('/Avenue/', 'Ave,', $title);
							$title = preg_replace('/Street,/', 'Street', $title);
							$title = preg_replace('/Street/', 'St,', $title);
							$title = preg_replace('/Place,/', 'Place', $title);
							$title = preg_replace('/Place/', 'Place,', $title);
							$title = preg_replace('/Blvd,/', 'Blvd', $title);
							$title = preg_replace('/Blvd/', 'Blvd,', $title);
							$title = preg_replace('/Parkway,/', 'Parkway', $title);
							$title = preg_replace('/Parkway/', 'Parkway,', $title);
						?>
						<h1 class="entry-title"><?= $title;?></h1>
						<?php if ($buildingtype || $neighborhood !='') {?>
							<h4 class="subtitle zeta"><?php if ($buildingtype !='') { echo $buildingtype . ', ';} if ($neighborhood !='') {echo $neighborhood;}  ?></h4>
						<?php } ?>
					</div>
				</div>
			</div>
			<?php // get_template_part('templates/entry-meta'); ?>
		</header>
		<!--
<div class="visible-xs-block">
			<?php the_post_thumbnail('large', array('class'=>'hauto w100 visible-xs-block')); ?>
		</div>
-->
		<div class=" img-feature parallax bkb-area center col-sm-12" data-stellar-background-ratio="0.85">
			<?php the_post_thumbnail('large', array('class'=>'h100 wauto ')); ?>
		</div>
		<div class="row">
		<div class="stats-bar col-sm-12">
			<div class="col-sm-2 stats hidden-xs">
				<?php if ($price > 0) { echo '$' . $price;} else { echo 'See Listing Agent';} echo '<small class="clearfix">Price</small>'; ?>
			</div>
			<?php ?>
			<div class=" col-sm-2 stats hidden-xs">
				<?php if ($units !='') {echo $units . '<small class="clearfix">Units</small>'; } ?>
			</div>

			<div class=" col-sm-2 stats hidden-xs">
				<?php if ($gross_sf !='') { echo $gross_sf . '<small class="clearfix">Gross SqFt</small>'; } ?>
			</div>

			<div class="col-sm-6 stats stats-available">
				<?php
				if ( in_category( 'under-contract' )) {
					echo '<a class="under-contract caps btn btn-default" href="/under-contract/"><i class="fa fa-circle"></i> Under Contract</a>';
				}
				elseif ( in_category( 'on-market' )) {
					echo '<a class="available caps btn btn-default" href="/on-market/"><i class="fa fa-circle"></i> Available</a>';
				} elseif ( in_category( 'recent-sales' )) {
					echo '<a class="sold caps btn btn-default" href="/recent-sales/"><i class="fa fa-circle"></i> Sold</a>';
				} else {
					// etc.
				}
				?>
			</div>
		</div>
		</div>
		<div class="spec-wrapper col-sm-12">
			<div class="container">
				<div class="row" >
					<div class="col-sm-4">
						<h5>Specifications</h5>
					</div>
					<div class="col-sm-8">
						<ul class="spec-list">
							<?php if ($gross_sf !='') {echo '<li><label>Gross SqFt</label>' . $gross_sf . '</li>';} ?>
							<?php if ($units !='') {echo '<li><label>Units</label>' . $units . '</li>';} ?>
							<?php if ($subtype !='') {echo '<li><label>Sub-Type</label>' . $subtype . '</li>';} ?>
							<?php if ($gross_rent > 0) {echo '<li><label>Gross Rent</label>$' . $gross_rent . '</li>';} ?>
							<?php if ($noi > 0) {echo '<li><label>NOI</label>$' . $noi . '</li>';} ?>
							<?php if ($cap_rate_current !='') {echo '<li><label>Cap Rate Current</label>' . $cap_rate_current . '</li>';} ?>
							<?php if ($cap_rate_proforma !='') {echo '<li><label>Cap Rate Pro-Forma</label>' . $cap_rate_proforma . '</li>';} ?>
							<?php if ($grm_current !='') {echo '<li><label>GRM Current</label>' . $grm_current . '</li>';} ?>
							<?php if ($grm_proforma !='') {echo '<li><label>GRM Pro-Forma</label>' . $grm_proforma . '</li>';} ?>
							<?php if ($ppsft > 0 ) {echo '<li><label>Price/SqFt</label>$' . $ppsft . '</li>';} ?>
							<?php if ($ppu > 0) {echo '<li><label>Price/Unit</label>$' . $ppu . '</li>';} ?>
							<?php if ($building_size !='') {echo '<li><label>Building Size</label>' . $building_size . '</li>';} ?>
							<?php if ($lot_size !='') {echo '<li><label>Lot Size</label>' . $lot_size . '</li>';} ?>
							<?php if ($year_built !='') {echo '<li><label>Year Built</label>' . $year_built . '</li>';} ?>
							<?php if ($total_buildable_sqft !='') {echo '<li><label>Total Buildable SqFt</label>' . $total_buildable_sqft . '</li>';} ?>
							<?php if ($far !='') {echo '<li><label>Far</label>' . $far . '</li>';} ?>
							<?php if ($approved_plans !='') {echo '<li><label>Approved Plans</label>' . $approved_plans . '</li>';} ?>
							<?php if ($existing_finance !='') {echo '<li><label>Existing Financing</label>' . $existing_finance . '</li>';} ?>
							<?php if ($bid_deadline !='') {echo '<li><label>BID Deadline</label>' . $bid_deadline . '</li>';} ?>
							<?php if ($renovated !='') {echo '<li><label>Renovated</label>' . $renovated . '</li>';} ?>
							<?php if ($list_to_close_ratio !='') {echo '<li><label>List to Close Ratio</label>' . $list_to_close_ratio . '</li>';} ?>
							<?php if ($number_of_offers !='') {echo '<li><label># of Offers</label>' . $number_of_offers . '</li>';} ?>
						</ul>
					</div>
				</div>
				<div class="row" style="padding-top: 40px;">
					<div class="col-sm-4">
						<h5>Pricing</h5>
					</div>
					<div class="col-sm-8">
						<ul class="spec-list">
							<?php if ($status !='') {echo '<li><label>Status</label>' . $status . '</li>';} ?>
							<?php if ($price_per_buildable_sqft > 0) {echo '<li><label>Price / Buildable SqFt</label>$' . $price_per_buildable_sqft . '</li>';} ?>
							<?php if ($financing !=='') { ?>
							<li><label><a rel="nofollow" href="<?= $financing; ?>">Get Financing <i class="arrrows">q</i></a></label></li>
							<?php } ?>
							<?php if ($price > 0) {echo '<li><label>Price</label>$' . $price . '</li>';} else { echo '<li><label>Price</label>See Listing Agent</li>';}  ?>
							<?php if ($offer !=='') { ?>
							<li><label><a rel="nofollow" href="<?= $offer; ?>">Make an Offer <i class="arrrows">q</i></a></label></li>
							<?php } ?>
						</ul>
					</div>
				</div>
			</div>
		</div>



		<?php if ( !empty($diligence) || !empty($dlm_id) || !empty($mpack) ) { ?>
		<div class="locked-section shaded-yellow col-sm-12 center">


			<?php if (!empty($diligence)) { ?>
				<a class="btn btn-outline btn-white odd inline <?php if (!is_user_logged_in()) {echo ' disabled';}?>" href="<?= $diligence; ?>" role="button" onclick="ss_te(event,2)" onmousedown="if((event.which == 3) || (event.button==2)){ss_te(event,3,false);}">
					<?php if (!is_user_logged_in()) {
						echo ' <i class="fa fa-fw fa-lock"></i> ';
					} ?> Due Diligence <i class="arrrows">q</i>

				</a>
			<?php }

			//echo do_shortcode('[download id="'.$dlm_id.'" template="button"]');
			if ($dlm_id !=='') {
				$args = array('post_type' => 'dlm_download', 'post__in' => array($dlm_id));

				$myposts = get_posts( $args );
				foreach ( $myposts as $post ) : setup_postdata( $post ); global $dlm_download; ?>

					<a class="download-link btn btn-outline btn-white even inline <?php if (!is_user_logged_in()) {echo ' disabled';}?>" title="<?php $dlm_download->the_title(); if ( $dlm_download->has_version_number() ) printf( __( 'Version %s', 'download_monitor' ), $dlm_download->get_the_version_number() ); ?>" href="<?php $dlm_download->the_download_link(); ?>" rel="nofollow">
						<?php if (!is_user_logged_in()) {
						echo ' <i class="fa fa-fw fa-lock"></i> ';
						} ?> Marketing Package <i class="arrrows">q</i>
					</a>

				<?php endforeach;
				wp_reset_postdata();
			} else  {
			?>
			<a class="btn btn-outline btn-white even inline <?php if (!is_user_logged_in()) {echo ' disabled';}?>" href="<?= $mpack; ?>" role="button" onclick="ss_te(event,2)" onmousedown="if((event.which == 3) || (event.button==2)){ss_te(event,3,false);}">
				<?php if (!is_user_logged_in()) {echo ' <i class="fa fa-fw fa-lock"></i> ';} ?>Marketing Package <i class="arrrows">q</i>
			</a>
			<?php } ?>
			<?php if (!is_user_logged_in()) {?>
			<div class="loginout row">
				<div class="col-sm-12">
					<p><a href="<?= wp_login_url(get_permalink()); ?>">Login</a> or <a href="<?= wp_registration_url(get_permalink()); ?>">Register</a> to unlock downloads.</p>
				</div>
			</div>
			<?php } ?>
		</div>
		<?php } ?>





		<div class="container">
			<?php if (!empty(get_the_content())) { ?>
			<div class="entry-content">
				<?php
				$content = get_the_content();
				$content = preg_replace("/<img[^>]+\>/i", " ", $content);
				$content = apply_filters('the_content', $content);
				$content = str_replace(']]>', ']]>', $content);
				echo $content;
				?>
			</div>
			<?php } ?>
			<div class="listing-team row">


				<div class="col-sm-4">
					<h5><?php if (in_category( 7, $post->ID )) :?>Exclusive Selling Team<?php else:?>Exclusive Listing Team<?php endif;?></h5>
				</div>
				<div class="col-sm-8">

					<?php

					$agents = get_post_meta(get_the_id(), '_nda_listing_brokers', 1);

					//print_r($agents);
					//print_r($nda_brokers);

					if ( $agents ) {
						echo '<ul class="col-2 property-brokers">';
						foreach ( $agents as $key => $agent) {

							$user_info = get_userdata($agent); ?>
							<li class="listedby">
								<p class="agent" style="font-size: 1.18em;">
									<?= '<a title="Link to '. $user_info->display_name.'&#39;s profile" href="'. get_author_posts_url( $agent ).'" target="_blank">' . $user_info->first_name . ' '  . $user_info->last_name .'</a>'; ?>
								</p>
								<?php
								if (get_user_meta($agent, '_nda_work_phone', 1)) {
									echo '<p class="phone" style="font-size: 1.2em;"><i class="fa fa-fw fa-phone"></i> ' . get_user_meta($agent, '_nda_work_phone', true) . '</p>';
								}
								if (isset($user_info->user_email)) {
									echo '<p class="email" style="font-size: 1.05em;"><i class="fa fa-fw fa-envelope"></i> <a title="Send an email to '.$user_info->display_name.'" href="mailto:'. $user_info->user_email . '?Subject=Inquiry / newyorkmultifamily.com " target="_top">' . $user_info->user_email . '</a></p>';
								}
								if (get_user_meta($agent, '_nda_lic', 1)) {
									echo '<p>LIC: ' . get_user_meta($broker_id, '_nda_lic', true) . '</p>';
								}
								?>
							</li>
							<?php
						}
						echo '</ul>';
					} elseif ( $nda_brokers ) { ?>
						<div class="row">
							<?php 
							foreach($nda_brokers as $broker_id){
								$curuser_id = $broker_id;
								$curauth = get_userdata( $broker_id );
								$user_info = get_userdata($broker_id);

								?>
							    <div class="col-md-6 listedby">
									<p class="agent">
										<a title="Link to <?php if (!empty($curauth->display_name)) { echo $curauth->display_name; } ?>&#39;s profile" href="<?= get_author_posts_url( $broker_id ); ?>" target="_blank">
											<?php //echo isset($curauth->display_name); ?>
											<?php if (!empty($curauth->display_name)) { echo $curauth->display_name; } ?>
										</a>
									</p>
									<?php if (get_user_meta($broker_id, '_nda_work_phone', true)){
										echo '<p class="phone"><i class="fa fa-fw fa-phone"></i> ' . get_user_meta($curuser_id, '_nda_work_phone', true) . '</p>';
									}?>
									<?php if (isset($curauth->user_email)){
										//<a href="mailto:someone@example.com?Subject=Hello%20again" target="_top">Send Mail</a>
										echo '<p class="email"><i class="fa fa-fw fa-envelope"></i> <a title="Send an email to '.$curauth->display_name.'" href="mailto:'. $curauth->user_email . '?Subject=Inquiry / newyorkmultifamily.com " target="_top">' . $curauth->user_email . '</a></p>';
									} ?>
									<?php if (get_user_meta($broker_id, '_nda_lic', true)) {
									echo '<p>LIC: ' . get_user_meta($broker_id, '_nda_lic', true) . '</p>';
									}?>
							    </div>
							<?php 
							} ?>
						</div>
					<?php } else { ?>
				    	<p style="text-transform:uppercase;"><b>No Listing Brokers</b></p>
				    <?php }  ?>
				</div> <!-- end col-sm-8 -->
			</div><!-- listing-team -->
		</div><!-- container -->


		<footer>
			<section>
				<div class="section-header">
					<div class="container" style="width: 100%;padding-left: 4%;">
						<h4>Latest Deals <small class="serif italic" style="text-transform:none;"><a href="/on-market/">See all deals <i class="arrrows">r</i></a></small></h4>
					</div>
				</div>
				<div class="related-listings col-sm-12">
					<ul class="col-6 related">
					<?php
					$category = get_the_category();
					$current_category = $category[0]->cat_name;
					$args = array(
						'posts_per_page' => 6,
						'exclude'=> get_the_id(),
						'orderby' => 'rand',
						'category'=>'on-market',
						'meta_query' => array(
					        array(
					         'key' => '_thumbnail_id',
					         'compare' => 'EXISTS'
					        ),
					    )
					 );
					$myposts = get_posts( $args );
					foreach ( $myposts as $post ) : setup_postdata( $post );
						$price = get_post_meta( $post->ID, '_nda_price', true ); ?>
						<?php if (has_post_thumbnail()) { ?>
						<li>
							<article>
								<a href="<?php the_permalink(); ?>">
									<figure>
										<?php the_post_thumbnail('listing-archive', array('class'=>'h100 w100')); ?>
										<figcaption class="serif">
											<?php
												$title = get_the_title();
												$title = preg_replace('/Avenue,/', 'Avenue', $title);
												$title = preg_replace('/Avenue/', 'Ave,<br/>', $title);
												$title = preg_replace('/Street,/', 'Street', $title);
												$title = preg_replace('/Street/', 'St,<br/>', $title);
												$title = preg_replace('/Place,/', 'Place', $title);
												$title = preg_replace('/Place/', 'Place,<br/>', $title);
												$title = preg_replace('/Blvd,/', 'Blvd', $title);
												$title = preg_replace('/Blvd/', 'Blvd,<br/>', $title);
												$title = preg_replace('/Parkway,/', 'Parkway', $title);
												$title = preg_replace('/Parkway/', 'Parkway,<br/>', $title);
												$price = preg_replace('~\.0+$~','',$price);
											?>
											<h3><?= $title; ?></h3>

											<p><em><?php if ($price > 0) { echo '$' . $price;} else { echo 'See Listing Agent';} ?></em></p>
										</figcaption>
									</figure>
								</a>
							</article>
						</li>
						<?php
						}
					endforeach; wp_reset_postdata();?>
					</ul>
				</div>
			</section>
			<?php wp_link_pages(array('before' => '<nav class="page-nav"><p>' . __('Pages:', 'roots'), 'after' => '</p></nav>')); ?>
		</footer>
			<?php // comments_template('/templates/comments.php'); ?>
	</article>
<?php endwhile; ?>
