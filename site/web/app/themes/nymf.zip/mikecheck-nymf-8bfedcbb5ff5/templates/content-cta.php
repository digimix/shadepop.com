<?php
use Roots\Sage\Extras;

$cta_headline = get_post_meta($post->ID, '_nda_cta_headline', 1);
$cta_copy = get_post_meta($post->ID, '_nda_cta_copy', 1);
$cta_btn = get_post_meta($post->ID, '_nda_cta_btn', 1);
$cta_url = get_post_meta($post->ID, '_nda_cta_url', 1);


if( '' !== $cta_headline || '' !== $cta_copy || '' !== $cta_url ) { ?>

<section class="cta shaded-brand text-center light-text">
	<?php if ($cta_headline !=='') { ?>
	<h2 class="caps" style="margin-bottom: 10px;"><?= $cta_headline; ?> </h2>
	<?php } if ($cta_copy !=='') { ?>
	<h4 class="delta" style="margin-bottom: 10px;"><?= $cta_copy; ?> </h4>
	<?php } if ($cta_url !=='') { ?>
	<a class="btn btn-outline btn-white delta" title="" href="<?= $cta_url; ?>"><?= $cta_btn; ?> <i class="arrrows">r</i></a>
	<?php } ?>
</section>
<?php } ?>