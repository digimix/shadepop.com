<header class="banner navbar yamm navbar-default navbar-static-top" role="banner">
	<div class="">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
				<?php $home_id = get_option( 'page_on_front' ); $logo = get_post_meta($home_id, '_nda_home_logo', 1);
					if ($logo !=='') { ?>
						<img style="background-color: white;" class="h100 wauto" alt="<?php bloginfo('name'); ?>" src="<?php echo $logo; ?>">
						<?php
					} else {?>
						<img style="background-color: white;" class="h100 wauto" alt="<?php bloginfo('name'); ?>" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/logo.png">

					<?php
					}
					 ?>
			</a>
		</div>

<!--
		<div class="loginout hidden-xs">
			<?php wp_loginout(get_permalink()); ?>
			<?php if (!is_user_logged_in()) { ?>
			<a href="<?php echo wp_registration_url(get_permalink()); ?>">Register</a>
			<?php } ?>
		</div>
-->

	    <nav role="navigation">
		<?php
		if (has_nav_menu('primary_navigation')) :
		    wp_nav_menu([
		        'menu_class'        => 'nav',
		        'theme_location'    => 'primary_navigation',
		        'depth'             => 2,
		        'container'         => 'div',
		        'container_class'   => 'collapse navbar-collapse',
			    'container_id'      => 'bs-example-navbar-collapse-1',
		        'menu_class'        => 'nav navbar-nav',
		        'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
		        'walker'            => new wp_bootstrap_navwalker()
		        ]
		    );
		endif;
		?>
<!--
			<ul id="menu-primary-navigation" class="nav navbar-nav hidden-xs" style="margin-top: -15px;">
				<li><?php wp_loginout(get_permalink()); ?></li>
				<?php if (!is_user_logged_in()) { ?>
				<li><a href="<?php echo wp_registration_url(get_permalink()); ?>">Register</a></li>
				<?php } ?>
			</ul>
-->

	    </nav>
	</div>
</header>
