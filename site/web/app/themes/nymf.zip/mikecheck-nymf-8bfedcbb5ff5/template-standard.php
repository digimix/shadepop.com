<?php
/*
Template Name: Standard + Agents Section
*/
use Roots\Sage\Extras;
while (have_posts()) : the_post();

	$agents = get_post_meta(get_the_id(), '_nda_featured_agents', 1);

	get_template_part('templates/page', 'header');

	if ( !empty(get_post_thumbnail_id())) { ?>

	<section class="banner" style="margin-top:-40px;background:url(  <?= Extras\featured_url('full'); ?>);"></section>

	<?php } ?>

	<div class="container page-content" style="padding-bottom: 40px;">
		<?php get_template_part('templates/content', 'page'); ?>
	</div>

	<?php get_template_part('templates/content-agents'); ?>

	<?php get_template_part('templates/content-cta'); ?>

<?php endwhile; ?>
