<?php
/**
 * Template Name: Services Template
 */

 use Roots\Sage\Extras;
?>

<?php while (have_posts()) : the_post(); ?>
  <?php get_template_part('templates/page', 'header'); ?>
  <?php get_template_part('templates/content', 'page'); ?>
  <?php //the_post_thumbnail('large', ['class'=>'img-responsive']); ?>
<?php endwhile; ?>

<section class="banner" style="background:url(  <?= Extras\featured_url('full'); ?>);"></section>

<div class="container">
	<ul class="col-2 m0">
		<?php
		$args = array( 'posts_per_page' => -1, 'post_type'=> 'service',);

		$myposts = get_posts( $args );
		foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
			<?php get_template_part('templates/content', get_post_type() != 'post' ? get_post_type() : get_post_format()); ?>
		<?php endforeach;
		wp_reset_postdata();?>

	<?php while (have_posts()) : the_post(); ?>
	<?php endwhile; ?>
	</ul>
</div>
<div class="container">
	<ul class="col-2 " style="margin-top: -1.375em;">
		<?php

		//$args = array( 'posts_per_page' => -1, 'post_type'=> 'service', );
		//$myposts = get_posts( $args );

		foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
		<li class="shaded-brand">
			<?php get_template_part('templates/content-cta'); ?>
		</li>
		<?php endforeach;
		wp_reset_postdata();?>
	</ul>
</div>

	<?php get_template_part('templates/content-agents'); ?>

	<?php get_template_part('templates/content-cta'); ?>
