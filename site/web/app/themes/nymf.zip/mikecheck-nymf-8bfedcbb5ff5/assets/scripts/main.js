/* ========================================================================
 * DOM-based Routing
 * Based on http://goo.gl/EUTi53 by Paul Irish
 *
 * Only fires on body classes that match. If a body class contains a dash,
 * replace the dash with an underscore when adding it to the object below.
 *
 * .noConflict()
 * The routing is enclosed within an anonymous function so that you can
 * always reference jQuery with $, even when in .noConflict() mode.
 * ======================================================================== */

(function($) {

  // Use this variable to set up the common and page specific functions. If you
  // rename this variable, you will also need to rename the namespace below.
  var Sage = {
    // All pages
    'common': {
      init: function() {
        // JavaScript to be fired on all pages
      },
      finalize: function() {
        // JavaScript to be fired on all pages, after page specific JS is fired
      }
    },
    // Home page
    'home': {
      init: function() {
        // JavaScript to be fired on the home page

		$(window).bind("load resize",function(e){ // On load
			var width = $(window).width();
			var height = $(window).height();
			var navbarH = $( "header.banner" ).height();
			var footerH = $( "footer" ).height();
			var adminBar = $("#wpadminbar").height();

			if (width >= 768) {
				$('.gallery.gallery-home').css({'height':( (height) / 1 ) - (navbarH + adminBar) });
				// $('body').fadeIn('fast');
				//$('.tab-pane.fade.toggle-mobile').removeClass('active in');
			}
			if (width <= 767) {
				$('.gallery.gallery-home').css({'height':( (height) / 1 - (navbarH + adminBar) ) });
				//$('.tab-pane.fade:not(.active)').addClass('toggle-mobile active in');
				// $('body').fadeIn('fast');
			}
		});


		$(document).ready(function(){

			/***************** Flickity ******************/
	        var flky = new Flickity( '.gallery.gallery-home', {
		        freeScroll: false,
		        autoPlay: false,
		        wrapAround: true,
			    contain: true,
			    setGallerySize: false,
			    pageDots: false,

	  		});

		});

      },
      finalize: function() {
        // JavaScript to be fired on the home page, after the init JS
      }
    },
    // About us page, note the change from about-us to about_us.
    'about_us': {
      init: function() {
        // JavaScript to be fired on the about us page
      }
    },

    // About us page, note the change from about-us to about_us.
    'category': {
      init: function() {
        // JavaScript to be fired on the about us page
		$("img.lazy").lazyload({
		    threshold : 300,
		    skip_invisible:true,
		    effect : "fadeIn"

		});

		$( ".listings-archive a figure figcaption" ).removeClass('hidden').fadeIn( "slow" );


/*
		function abbreviateNumber(n) {
		    math.eval(
		        var base = floor(log(abs(n))/log(1000));
		        var suffix = 'kmb'[base-1];
		        return suffix ? String(n/pow(1000,base)).substring(0,5)+suffix : ''+n;
		    );
		}
*/

		function abbreviateNumber(value) {
		    var newValue = value;
		    if (value >= 1000) {
		        var suffixes = ["", "k", "m", "b","t"];
		        var suffixNum = Math.floor( (""+value).length/3 );
		        var shortValue = '';
		        for (var precision = 2; precision >= 1; precision--) {
		            shortValue = parseFloat( (suffixNum !== 0 ? (value / Math.pow(1000,suffixNum) ) : value).toPrecision(precision));
		            var dotLessShortValue = (shortValue + '').replace(/[^a-zA-Z 0-9]+/g,'');
		            if (dotLessShortValue.length <= 2) { break; }
		        }
		        if (shortValue % 1 !== 0) {shortNum = shortValue.toFixed(1);}
		        newValue = shortValue+suffixes[suffixNum];
		    }
		    return newValue;
		}

		// price range
		var price_slide_min_val = 0;
		var price_slide_step = $("#price-range").data('slide-step');
		var price_slide_nomax = 20000000;
		var price_slide_last_val = $("#price-range").data('slide-last-val');
		var price_slide_max_val = price_slide_last_val + price_slide_nomax;

		var def_currency = $("#price-range").data('def-currency');
		var min_price = $("#price-range").data('min-price');
		var max_price = $("#price-range").data('max-price');
		if (max_price === "no_max") { max_price = price_slide_max_val; }


		$(document).ready(function() {
		    $("#price-range").slider({
		        range: true,
		        min: min_price,
		        max: max_price,
		        step: price_slide_step,
		        values: [ min_price, max_price ],
		        slide: function( event, ui ) {
		            // make handles uncollapse
		            if ((ui.values[0] + 1) >= ui.values[1]) {
		                return false;
		            }

			        // min price text
			        min_price = ui.values[0];
		            $(".min-price-label").html( "$" + abbreviateNumber(min_price));

		            // max price text
		            max_price = ui.values[1];
		            if (max_price === price_slide_max_val) {
		                max_price = price_slide_last_val + '+';
		            }
		            $(".max-price-label").html( "$" + abbreviateNumber(max_price));

					var currMax = $("#price-range").slider('option', 'max');
					if (ui.values[1] === currMax) {
				         // $(".max-price-label").html( "unlimited");
				         $(".max-price-label").html( "$" + abbreviateNumber(max_price) + "+");
					}

		            $('li[data-price]').each(function() {
		                var dPrice = $(this).attr('data-price');
		                if ( (ui.values[1] === currMax) && dPrice >= max_price ) {
		                    //$(this).show();
		                    $(this).removeClass( "hidden" );
		                    $(this).addClass( "visible" );

		                } else if ( dPrice < min_price || dPrice > max_price ) {
			                //$(this).hide();
			                $(this).removeClass( "visible" );
			                $(this).addClass( "hidden" );

		                } else {
		                	//$(this).show();
		                	$(this).addClass( "visible" );
		                	$(this).removeClass( "hidden" );
		            	}
		            });
		        }
		    }).slider("pips", {
				first: 'pip',
				last: 'pip',
		        step: 5,
		    });

		    // $( "#price-range" ).slider( "option", "values", [ 500000, 12500000 ] );
		    // $(".max-price-label").html( "$" + abbreviateNumber($("#price-range").slider( "values", 1 )));

		    $(".min-price-label").html( "$" + abbreviateNumber($("#price-range").slider( "values", 0 )));
		    $(".max-price-label").html( "$" + abbreviateNumber($("#price-range").slider( "values", 1 ))+ "+");

		    $("#rating").slider({
		        range: "min",
		        value: 40,
		        min: 0,
		        max: 50,
		        slide: function( event, ui ) {

		        }
		    });
		});

      }
    },


  };

  // The routing fires all common scripts, followed by the page specific scripts.
  // Add additional events for more control over timing e.g. a finalize event
  var UTIL = {
    fire: function(func, funcname, args) {
      var fire;
      var namespace = Sage;
      funcname = (funcname === undefined) ? 'init' : funcname;
      fire = func !== '';
      fire = fire && namespace[func];
      fire = fire && typeof namespace[func][funcname] === 'function';

      if (fire) {
        namespace[func][funcname](args);
      }
    },
    loadEvents: function() {
      // Fire common init JS
      UTIL.fire('common');

      // Fire page-specific init JS, and then finalize JS
      $.each(document.body.className.replace(/-/g, '_').split(/\s+/), function(i, classnm) {
        UTIL.fire(classnm);
        UTIL.fire(classnm, 'finalize');
      });

      // Fire common finalize JS
      UTIL.fire('common', 'finalize');
    }
  };

  // Load Events
  $(document).ready(UTIL.loadEvents);

})(jQuery); // Fully reference jQuery after this point.
