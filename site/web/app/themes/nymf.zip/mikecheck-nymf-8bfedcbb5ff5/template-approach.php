<?php
/*
Template Name: Approach
*/

use Roots\Sage\Titles;

while (have_posts()) : the_post();
$subtitle = get_post_meta(get_the_id(), '_nda_subtitle', true);

?>

<div class="page-header hero parallax">
	<h1>
		<?= Titles\title(); ?>
	</h1>
	<?php if ($subtitle !='') {?>
	<p class="subtitle">
		<?= $subtitle; ?>
	</p>
	<?php } ?>
	<div class="container">
		<div class="summary">
			<p><?php the_content(); ?></p>
		</div>
	</div>
</div>


<div class="timeline">
	<div class="milestone offset-first">
		<h3>Timeline of a Typical Transaction</h3>
		<p class="subtitle">Broad Exposure Approach</p>
	</div>
<?php $milestones = get_post_meta(get_the_id(), '_nda_repeat_milestone' , true);
	$i=0;foreach ( (array) $milestones as $key => $milestone ) {
	    // $img = $title = $desc = $caption = '';

	    if ( isset( $milestone['m_title'] ) )
	        $title = esc_html( $milestone['m_title'] );

	    if ( isset( $milestone['m_copy'] ) )
	        $desc = wpautop( $milestone['m_copy'] );

	    if ( isset( $milestone['m_days'] ) )
	        $days = $milestone['m_days'];

	    if ( isset( $milestone['m_ico'] ) )
	        $icon = $milestone['m_ico'];

	        $i++;
?>
		<div class="milestone <?= ($i%2 ? 'odd':'even'); ?>">
			<header>
				<h4 class="m0"><?= $title;?></h4>
				<p class="subtitle"><?= $days;?></p>
				<i class="fa <?= $icon; ?>"></i>
			</header>
			<p><?= $desc; ?></p>
		</div>
<?php } ?>
</div>



<!--
<section>
	<div class="section-header center">
		<div class="container">
			<h4>Property Valuation</h4>
		</div>
	</div>
	<div class="section-content gradient">
		<div class="container" style="padding-top:40px;padding-bottom: 20px;">
			<div class="row center">
				<div class="col-md-12">
				<p class="gamma m0" style="color:white">Market conditions change frequently. Request a no obligation, real-time evaluation for your property.</p>
					<a href="/property-evaluation" class="btn btn-outline btn-white" style="margin-bottom:20px;background:transparent;color:inherit;">Get My Evaluation</a>
				</div>
			</div>
		</div>
	</div>
</section>
-->
	<?php get_template_part('templates/content-agents'); ?>

	<?php get_template_part('templates/content-cta'); ?>

<?php endwhile; ?>