<?php

/**
 * Adds a box to the main column on the Post and Page edit screens.
 */
function ndaproperty_address_add_custom_box() {

    $screens = array( 'post');

    foreach ( $screens as $screen ) {

        add_meta_box(
            'ndaproperty_address_sectionid',
            __( 'Property Address', 'ndaproperty_address_textdomain' ),
            'ndaproperty_address_inner_custom_box',
            $screen
        );
    }
}
add_action( 'add_meta_boxes', 'ndaproperty_address_add_custom_box' );

/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
require_once('property-address-metabox.php');

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function ndaproperty_address_save_postdata( $post_id ) {

  /*
   * We need to verify this came from the our screen and with proper authorization,
   * because save_post can be triggered at other times.
   */

  // Check if our nonce is set.
  if ( ! isset( $_POST['ndaproperty_address_inner_custom_box_nonce'] ) )
    return $post_id;

  $nonce = $_POST['ndaproperty_address_inner_custom_box_nonce'];

  // Verify that the nonce is valid.
  if ( ! wp_verify_nonce( $nonce, 'ndaproperty_address_inner_custom_box' ) )
      return $post_id;

  // If this is an autosave, our form has not been submitted, so we don't want to do anything.
  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
      return $post_id;

  // Check the user's permissions.
  if ( 'page' == $_POST['post_type'] ) {

    if ( ! current_user_can( 'edit_page', $post_id ) )
        return $post_id;

  } else {

    if ( ! current_user_can( 'edit_post', $post_id ) )
        return $post_id;
  }

  /* OK, its safe for us to save the data now. */

  // Sanitize user input.
  $nda_address_1 = sanitize_text_field( $_POST['_nda_address_1']);
  $nda_address_2 = sanitize_text_field( $_POST['_nda_address_2']);
  $nda_city = sanitize_text_field( $_POST['_nda_city']);
  $nda_state = sanitize_text_field( $_POST['_nda_state']);
  $nda_zip = sanitize_text_field( $_POST['_nda_zip']);
  $nda_neighborhood = sanitize_text_field( $_POST['_nda_neighborhood']);
  $nda_latitude = sanitize_text_field( $_POST['_nda_latitude']);
  $nda_longitude = sanitize_text_field( $_POST['_nda_longitude']);

  // Update the meta field in the database.
  update_post_meta( $post_id, '_nda_address_1', $nda_address_1 );
  update_post_meta( $post_id, '_nda_address_2', $nda_address_2 );
  update_post_meta( $post_id, '_nda_city', $nda_city );
  update_post_meta( $post_id, '_nda_state', $nda_state );
  update_post_meta( $post_id, '_nda_zip', $nda_zip );
  update_post_meta( $post_id, '_nda_neighborhood', $nda_neighborhood );
  update_post_meta( $post_id, '_nda_latitude', $nda_latitude );
  update_post_meta( $post_id, '_nda_longitude', $nda_longitude );

}
add_action( 'new_to_publish', 'ndaproperty_address_save_postdata' );
add_action( 'save_post', 'ndaproperty_address_save_postdata' );

class nda_property_address{

    public function __construct($pid) {
        $this->postid = $pid;
    }

    function seoUrl($string) {
    //Lower case everything
    $string = strtolower($string);
    //Make alphanumeric (removes all other characters)
    $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
    //Clean up multiple dashes or whitespaces
    $string = preg_replace("/[\s-]+/", " ", $string);
    //Convert whitespaces and underscore to dash
    $string = preg_replace("/[\s_]/", "+", $string);
    return $string;
    }

    function do_all(){
      $this->address_1;
      $this->address_2;
      $this->city;
      $this->zip;
      $this->neighborhood;
      $this->latitude;
      $this->longitude;
    }

    function gmaps(){
      $lat = get_post_meta( $this->postid, '_nda_latitude', true );
      $lon = get_post_meta( $this->postid, '_nda_longitude', true );
      $title = get_post_meta( $this->postid, '_nda_address_1', true );
      $gmaps = array($title, $lat, $lon);
      return $gmaps;
      //return "[" . "'" . $title . "'" . "," . $lat . "," . $lon . "," . "4" . "]" . ",";
    }

    function gmap_url(){
      //https://www.google.com/maps/preview?q=5122+Snyder+Avenue,+Brooklyn,+NY+11203
      $address_1 = get_post_meta( $this->postid, '_nda_address_1', true );
      $address_1 = $this->seoUrl($address_1);

      $city = get_post_meta( $this->postid, '_nda_city', true );
      $city = $this->seoUrl($city);

      $state = get_post_meta( $this->postid, '_nda_state', true );
      $state = $this->seoUrl($state);

      $zip = get_post_meta( $this->postid, '_nda_zip', true );
      $zip = $this->seoUrl($zip);

      $open = 'https://www.google.com/maps/preview?q=';
      $url = $open . $address_1 . '+' . $city . '+' . $state . '+' . $zip;
      return $url;
    }

    function address_1(){
      $address_1 = get_post_meta( $this->postid, '_nda_address_1', true );
      if ($address_1 != Null) {
        echo $address_1;
      }
    }
    function address_2(){
      $address_2 = get_post_meta( $this->postid, '_nda_address_2', true );
      if ($address_2 != Null) {
        echo $address_2;
      }
    }
    function city(){
      $city = get_post_meta( $this->postid, '_nda_city', true );
      if ($city != Null) {
        echo $city;
      }
    }
    function state(){
      $state = get_post_meta( $this->postid, '_nda_state', true );
      if ($state != Null) {
        echo $state;
      }
    }
    function zip(){
      $zip = get_post_meta( $this->postid, '_nda_zip', true );
      if ($zip != Null) {
        echo $zip;
      }
    }
    function neighborhood(){
      $neighborhood = get_post_meta( $this->postid, '_nda_neighborhood', true );
      if ($neighborhood != Null) {
        echo $neighborhood;
      }
    }
    function latitude(){
      $latitude = get_post_meta( $this->postid, '_nda_latitude', true );
      if ($latitude != Null) {
        echo $latitude;
      }
    }
    function longitude(){
      $longitude = get_post_meta( $this->postid, '_nda_longitude', true );
      if ($longitude != Null) {
        echo $longitude;
      }
    }
}

?>