<?php

class NDA_AdUnits{

  public function __construct($pid) {
      $this->postid = $pid;
  }

  function do_all(){
    // $this->address_1;
  }

  function str_keyvalue($key, $value){
    $namespace = 'kv';
    $namespace + $key
    if
  }

  // function address_1(){
  //   $address_1 = get_post_meta( $this->postid, '_nda_address_1', true );
  //   if ($address_1 != Null) {
  //     echo $address_1;
  //   }
  // }

?>