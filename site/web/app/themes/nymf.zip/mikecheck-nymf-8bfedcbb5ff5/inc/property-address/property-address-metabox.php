<?php
/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
function ndaproperty_address_inner_custom_box( $post ) {

  // Add an nonce field so we can check for it later.
  wp_nonce_field( 'ndaproperty_address_inner_custom_box', 'ndaproperty_address_inner_custom_box_nonce' );

  //echo '<label for="ndaproperty_address_new_field">';
  echo  '<style>
          .large-4 {
            position: relative;
            width: 31.3333333%;
          }
          #ndaproperty_address_sectionid input{
            width:100%;
          }
          @media only screen {
            .column,
            .columns {
              position: relative;
              padding-left: 1%;
              padding-right: 1%;
              float: left;
            }
          }
          .latlong-lookup{
            line-height:1em;
            margin-top:20px;
          }
          </style>';
  echo '<form><fieldset><div class=\'row\'>';

//16 Court St Brooklyn, NY 11241

  // Field #1
  $nda_address_1 = get_post_meta( $post->ID, '_nda_address_1', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Address 1' .'</label>';
  echo '<input type=\'text\' name=\'_nda_address_1\' value=\'' . esc_attr( $nda_address_1 ) . '\' placeholder=\'16 Court Street\'>';
  echo '</div>';

  // Field #2
  $nda_address_2 = get_post_meta( $post->ID, '_nda_address_2', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Address 2' .'</label>';
  echo '<input type=\'text\' name=\'_nda_address_2\' value=\'' . esc_attr( $nda_address_2 ) . '\' placeholder=\'Floor 2A\'>';
  echo '</div>';

  // Field #3
  $nda_city = get_post_meta( $post->ID, '_nda_city', true );
  echo '<div class=\'large-4 columns\'><label>'. 'City' .'</label>';
  echo '<input type=\'text\' name=\'_nda_city\' value=\'' . esc_attr( $nda_city ) . '\' placeholder=\'Brooklyn\'>';
  echo '</div>';

  // Field #4
  $nda_state = get_post_meta( $post->ID, '_nda_state', true );
  echo '<div class=\'large-4 columns\'><label>'. 'State' .'</label>';
  echo '<input type=\'text\' name=\'_nda_state\' value=\'' . esc_attr( $nda_state ) . '\' placeholder=\'NY\'>';
  echo '</div>';

  // Field #5
  $nda_zip = get_post_meta( $post->ID, '_nda_zip', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Zip Code' .'</label>';
  echo '<input type=\'text\' name=\'_nda_zip\' value=\'' . esc_attr( $nda_zip ) . '\' placeholder=\'11241\'>';
  echo '</div>';

  // Field #6
  $nda_neighborhood = get_post_meta( $post->ID, '_nda_neighborhood', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Neighborhood' .'</label>';
  echo '<input type=\'text\' name=\'_nda_neighborhood\' value=\'' . esc_attr( $nda_neighborhood ) . '\' placeholder=\'Brooklyn Heights\'>';
  echo '</div>';

  // Field #7
  $nda_latitude = get_post_meta( $post->ID, '_nda_latitude', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Latitude' .'</label>';
  echo '<input type=\'text\' name=\'_nda_latitude\' value=\'' . esc_attr( $nda_latitude ) . '\' placeholder=\'40.693497\'>';
  echo '</div>';

  // Field #8
  $nda_longitude = get_post_meta( $post->ID, '_nda_longitude', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Longitude' .'</label>';
  echo '<input type=\'text\' name=\'_nda_longitude\' value=\'' . esc_attr( $nda_longitude ) . '\' placeholder=\'-73.990721\'>';
  echo '</div>';

  //Latitude & Longitude lookup link
  echo '<div class=\'large-4 columns latlong-lookup\'>';
  echo '<a href="http://itouchmap.com/latlong.html" target="_blank">Lat-Long Lookup</a>';
  echo '</div>';

  echo'</div></fieldset></form>';

}
?>