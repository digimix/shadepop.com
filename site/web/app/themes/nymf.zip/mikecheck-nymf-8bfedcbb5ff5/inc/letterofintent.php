<?php //get_header(); ?>
<!doctype html>
<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ -->
<!--[if lt IE 7]> <html class='no-js ie6 oldie' lang='en-US' > <![endif]-->
<!--[if IE 7]>    <html class='no-js ie7 oldie' lang='en-US' > <![endif]-->
<!--[if IE 8]>    <html class='no-js ie8 oldie' lang='en-US' '> <![endif]-->
<!-- Consider adding an manifest.appcache: h5bp.com/d/Offline -->
<!--[if gt IE 8]><!--> <html class='no-js' lang='en-US' > <!--<![endif]-->
<head>
  <link rel='stylesheet' id='reverie-stylesheet-css'  href='http://bkmultifamily.com/wp-content/themes/reverie-master/css/style.css' type='text/css' media='all' />
  <link rel='stylesheet' id='therineygroup-stylesheet-css'  href='http://bkmultifamily.com/wp-content/themes/reverie-master/css/therineygroup.css' type='text/css' media='all' />
</head>
<body>
<form>
  <fieldset>
    <legend>Letter of Intent</legend>

    <div class='row'>
      <div class='large-4 columns'>
        <label>Date</label>
        <input type='text' placeholder='large-4.columns'>
      </div>
      <div class='large-12 columns'>
        <label>Address</label>
        <input type='text' placeholder='large-12.columns'>
      </div>
      <div class='large-4 columns'>
        <label>City</label>
        <input type='text' placeholder='large-4.columns'>
      </div>
      <div class='large-4 columns'>
        <label>State</label>
        <input type='text' placeholder='large-4.columns'>
      </div>
      <div class='large-4 columns'>
        <label>Zip Code</label>
        <input type='text' placeholder='large-4.columns'>
      </div>
      <div class='small-12 large-12 columns'><hr/></div>
      <div class='small-12 large-12 columns'>
        <div class='loi-instructions'>
          <p>This letter will confirm our interest in purchasing the property referenced above under the terms and conditions outlined
          below. This represents a Non-Binding Letter of Intent.</p>
          <h2>Sign below and fax back to 646-349-2282</h2>
        </div>
      </div>
      <div class='small-12 large-12 columns'><hr/></div>
    </div>

    <div class='row'>
      <div class='large-4 columns'>
        <label>First Name</label>
        <input type='text' placeholder='John'>
      </div>
      <div class='large-4 columns'>
        <label>Last Name</label>
        <input type='text' placeholder='Smith'>
      </div>
<!--       <div class='large-4 columns'>
        <div class='row collapse'>
          <label>Title & Company</label>
          <div class='small-9 columns'>
            <input type='text' placeholder='small-9.columns'>
          </div>
          <div class='small-3 columns'>
            <span class='postfix'>.com</span>
          </div>
        </div>
      </div> -->
      <div class='small-12 large-12 columns'>
        <label>Contract Deposit</label>
        <input type='text' placeholder=''>
      </div>
      <div class='small-12 large-12 columns'>
        <label>Purchaser Price</label>
        <input type='text' placeholder=''>
      </div>
      <div class='small-12 large-12 columns'>
        <label>Financing</label>
        <input type='text' placeholder='Non-Contingent on Financing'>
      </div>
      <div class='small-12 large-12 columns'>
        <label>Due Dilligence Period</label>
        <input type='text' placeholder='Before Contract Signing'>
      </div>
      <div class='small-12 large-12 columns'>
        <label>Property Condition</label>
        <input type='text' placeholder='Property Sold "As Is"'>
      </div>
      <div class='small-12 large-12 columns'>
        <label>Environmental</label>
        <input type='text' placeholder='Property Sold "As Is"'>
      </div>
      <div class='small-12 large-12 columns'>
        <label>Violations</label>
        <input type='text' placeholder='Property Sold "As Is"'>
      </div>
      <div class='small-12 large-12 columns'>
        <label>Closing Date</label>
        <input type='text' placeholder=''>
      </div>
      <div class='small-12 large-12 columns'>
        <label>Brokerage Commision</label>
        <input type='text' placeholder='Per Separate Agreement With Seller'>
      </div>
    </div>

    <div class='row'>
      <div class='small-12 large-12 columns'><hr/></div>
      <div class='large-12 columns'>
        <label>Signed and Accepted (Buyer)</label>
        <textarea placeholder='small-12.columns'></textarea>
      </div>
      <div class='large-12 columns'>
        <label>Signed and Accepted (Seller)</label>
        <textarea placeholder='small-12.columns'></textarea>
      </div>
    </div>

  </fieldset>
</form>
<footer class="row full-width" role="contentinfo">
      <div class="small-12 large-12 columns footnav" align="center">
        <p>www.BKMultiFamilyGroup.com</p>
      </div>
      <div class="small-12 large-12 columns" align="center">
        <div class="copyright">
          <p>© 2012 Shaun Riney Group . Marcus & Millichap . 16 Court Street . Floor 2A . Brooklyn, NY 11241</p>
          <p>site by Nda Brooklyn</p>
        </div>
        <div class="disclaimer">
          <p>The representations contained on this internet page are provided based on information deemed
    reliable. However, the same has not been independently verified. Principals are advised to conduct a thorough due diligence for any potential transaction. Marcus & Millichap Real Estate Investment Services name and logo are used herein for information purposes only.</p>
        </div>
      </div>
</footer>
</body>
</html>
<?php //get_footer(); ?>