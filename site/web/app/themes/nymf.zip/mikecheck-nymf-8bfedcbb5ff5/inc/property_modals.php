<?php

function nda_send_email($download_contents=''){
	$prop_documents = new Attachments( 'property_attachments' );

	if(isset($_POST['submitted'])) {

	    if(trim($_POST['email']) === '')  {
	        $emailError = 'Please enter your email address.';
	        $hasError = true;
	    } else if (!preg_match("/^[[:alnum:]][a-z0-9_.-]*@[a-z0-9.-]+\.[a-z]{2,4}$/i", trim($_POST['email']))) {
	        $emailError = 'You entered an invalid email address.';
	        $hasError = true;
	    } else {
	        $email = trim($_POST['email']);
	    }

	    if(!isset($hasError)) {
	        $emailTo = get_option('tz_email');
	        if (!isset($emailTo) || ($emailTo == '') ){
	            $emailTo = get_option('admin_email');
	        }
	        $subject = '[bkmultifamily.com] From ';

	        $obj = json_decode($download_contents);

	        //print_r($obj);

	        //$body = file_get_contents('emails/file-download.html', true); 
			//print_r($body);
	       

	       	$thefilelink = $obj->guid;
			$thefilename = $obj->post_name;


	        $body = "Name: " . $thefilename . " \n\nEmail: $email \n\nFile: " . $thefilelink;

	        $corp_body = "I just downloaded a file. \n\n" . $body;
	        
	        $client_headers = 'From: '  . ' <' . $emailTo .'>' . "\r\n" . 'Reply-To: ' . $emailTo;

	        $corp_headers = 'From: '  . ' <' . $email .'>' . "\r\n" . 'Reply-To: ' . $email;

	        wp_mail($email, $subject, $body, $client_headers);
	        wp_mail($emailTo, $subject, $corp_body, $corp_headers);
	        $emailSent = true;
	    }
	}
}

?>

<?php 
// $body = file_get_contents('emails/file-download.html', true); 
// print_r($body);
?>



<?php $prop_documents = new Attachments( 'property_attachments' ); /* pass the instance name */ ?>

<!-- THINGTHING BUTTONS -->
<div class="small-12 large-6 columns listingLeft">
	<a class="button btnfull bLeft" href="#small-dialog">Due Dilligence</a>
	
	<?php if( $prop_documents->exist() ) : ?>
		<a class="popup-with-zoom-anim button btnfull bRight" href="#small-dialog">Marketing Package</a>

				<!-- MODAL WITH NESTED ROWS. -->
				<div id="small-dialog" class="zoom-anim-dialog mfp-hide">
					<div class="row">
						<h2>Marketing Package</h2>
					</div>
					<?php while( $prop_documents->get() ) : ?>

						<?php $downloadtype = $prop_documents->field( 'option' ); ?>

						<?php if(is_array($downloadtype)){
							$downloadtype = $downloadtype[0];
						}?>

						<?php if ($downloadtype == 0):?> <!-- Free -->
							<div class="row">
					  			<div class="small-8 columns">
					  				<h5><?php echo $prop_documents->field( 'title' ); ?></h5>
					  			</div>
					  			<div class="small-4 columns">
					  				<p class="">
					  					<a class="" style="float: right;" href="<?php echo $prop_documents->url(); ?>">Download</a>
					  					<small class="">Free</small>
					  				</p>
					  			</div>
							</div>
							<?php $filestuff = json_encode(get_post($prop_documents->id())); ?>
							<?php nda_send_email($filestuff);?>
						<?php endif;?> <!-- eND Free -->



						<?php if ($downloadtype == 1):?> <!-- Email -->
							<div class="row">
					  			<div class="small-8 columns">
					  				<h5><?php echo $prop_documents->field( 'title' ); ?></h5>
					  			</div>
					  			<div class="small-4 columns">
					  				<p class="">
					  					<a class="popup-with-zoom-anim" style="float: right;" href="#email-required-form-<?php echo $prop_documents->id(); ?>">Download</a>
					  					<small class="">Email required</small>
					  				</p>
					  			</div>
							</div>
							<div id="email-required-form-<?php echo $prop_documents->id(); ?>" class="email-required-form zoom-anim-dialog mfp-hide">
								<div class="row">
									<!-- <h2>Please ENTER your email address</h2> -->
									<!-- <p><?php echo $prop_documents->post_id(); ?></p>
									<p><?php echo $prop_documents->id(); ?></p> -->
									<form data-abide="" action="<?php the_permalink(); ?>" id="contactForm" method="post" class="message">
					                    <fieldset>
					                      <legend>Please Enter Your Email Address</legend>
					                      <input type="hidden" name="submitted" value="new">
					                      <div class="row">
					                        <div class="large-12 columns">
					                          <div class="contactField leftField">
					                            <label for="email">Email</label>
					                            <input type="text" name="email" id="email" value="" class="required requiredField email">
					                          </div>
					                        </div>
					                      </div>
					                      <div class="row">
					                        <div class="large-12 columns">
					                          <input class="button fullButton" type="submit" id="submit" tabindex="5" value="Download">

					                          <input type="hidden" name="postid" id="postid" value="<?php echo $prop_documents->post_id(); ?>">
					                          <input type="hidden" name="attachmentid" id="attachmentid" value="<?php echo $prop_documents->id(); ?>">


					                          <input type="hidden" name="submitted" id="submitted" value="true">
					                        </div>
					                      </div>
					                    </fieldset>
					                  </form>
								</div>
							</div>
							<?php $filestuff = json_encode(get_post($prop_documents->id())); ?>
							<?php nda_send_email($filestuff);?>
						<?php endif;?><!--  eND Email -->



						<?php if ($downloadtype == 2):?> <!-- Information Required -->
							<div class="row">
					  			<div class="small-8 columns">
					  				<h5><?php echo $prop_documents->field( 'title' ); ?></h5>
					  			</div>
					  			<div class="small-4 columns">
					  				<p class="">
					  					<a class="" style="float: right;" href="<?php echo $prop_documents->url(); ?>">Download</a>
					  					<small class="">info required</small>
					  				</p>
					  			</div>
							</div>
							<?php $filestuff = json_encode(get_post($prop_documents->id())); ?>
							<?php nda_send_email($filestuff);?>
						<?php endif;?> <!-- eND Information Required -->



						<?php if ($downloadtype == 3 && is_user_logged_in()):?> <!-- Login Required -->
							<div class="row">
					  			<div class="small-8 columns">
					  				<h5><?php echo $prop_documents->field( 'title' ); ?></h5>
					  			</div>
				  				<p class="">
				  					<a class="" style="float: right;" href="<?php echo $prop_documents->url(); ?>">Download</a>	
				  				</p>
							</div><?php $filestuff = json_encode(get_post($prop_documents->id())); ?>
							<?php nda_send_email($filestuff);?>
                            <?php else : ?> <div class="row">
					  			<div class="small-8 columns">
					  				<h5><?php echo $prop_documents->field( 'title' ); ?></h5>
					  			</div>
				  				<p class="">
				  					 <div class="" style="float: right;"><a href="/wp-login.php">Login</a> or <a href="/wp-login.php?action=register">Register</a></div><br>
                                    <small class="">To access this file a login is required</small>

				  				</p>
							</div>
							<?php $filestuff = json_encode(get_post($prop_documents->id())); ?>
							<?php nda_send_email($filestuff);?>
						<?php endif;?><!-- eND Login Required -->


					<?php endwhile; ?>

				</div><!-- END MODAL -->
	<?php else : ?>
		<div class="button bRight nonactivebtn btnfull" href="#small-dialog">Marketing Package</div>
	<?php endif; ?>
</div> <!-- END THINGTHING BUTTONS -->