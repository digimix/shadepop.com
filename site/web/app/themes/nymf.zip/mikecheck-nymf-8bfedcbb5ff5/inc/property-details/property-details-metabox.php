<?php
/**
 * Prints the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function ndaproperty_details_inner_custom_box( $post ) {

  // Add an nonce field so we can check for it later.
  wp_nonce_field( 'ndaproperty_details_inner_custom_box', 'ndaproperty_details_inner_custom_box_nonce' );

  //echo '<label for="ndaproperty_new_field">';
  echo  '<style>
          .large-4 {
            position: relative;
            width: 31.3333333%;
          }
          #ndaproperty_sectionid input{
            width:100%;
          }
          @media only screen {
            .column,
            .columns {
              position: relative;
              padding-left: 1%;
              padding-right: 1%;
              float: left;
            }
          }
          </style>';
  echo '<fieldset><div class=\'row\'>';

//16 Court St Brooklyn, NY 11241

  // Field #1
  $nda_gross_sf = get_post_meta( $post->ID, '_nda_gross_sf', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Gross SF' .'</label>';
  echo '<input type=\'text\' name=\'_nda_gross_sf\' value=\'' . esc_attr( $nda_gross_sf ) . '\' placeholder=\'59,000\'>';
  echo '</div>';

  // Field #2
  $nda_units = get_post_meta( $post->ID, '_nda_units', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Units' .'</label>';
  echo '<input type=\'text\' name=\'_nda_units\' value=\'' . esc_attr( $nda_units ) . '\' placeholder=\'58\'>';
  echo '</div>';

  // Field #3
  $nda_subtype = get_post_meta( $post->ID, '_nda_subtype', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Sub-Type' .'</label>';
  echo '<input type=\'text\' name=\'_nda_subtype\' value=\'' . esc_attr( $nda_subtype ) . '\' placeholder=\'Multi-Family\'>';
  echo '</div>';

  // Field #4
  $nda_price = get_post_meta( $post->ID, '_nda_price', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Price' .'</label>';
  echo '<input type=\'text\' name=\'_nda_price\' value=\'' . esc_attr( $nda_price ) . '\' placeholder=\'$1,900,000\'>';
  echo '</div>';

  // Field #5
  $nda_gross_rent = get_post_meta( $post->ID, '_nda_gross_rent', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Gross Rent' .'</label>';
  echo '<input type=\'text\' name=\'_nda_gross_rent\' value=\'' . esc_attr( $nda_gross_rent ) . '\' placeholder=\'$562,000\'>';
  echo '</div>';

  // Field #6
  $nda_noi = get_post_meta( $post->ID, '_nda_noi', true );
  echo '<div class=\'large-4 columns\'><label>'. 'NOI' .'</label>';
  echo '<input type=\'text\' name=\'_nda_noi\' value=\'' . esc_attr( $nda_noi ) . '\' placeholder=\'NOI\'>';
  echo '</div>';

  // Field #7
  $nda_cap_rate_current = get_post_meta( $post->ID, '_nda_cap_rate_current', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Cap Rate Current' .'</label>';
  echo '<input type=\'text\' name=\'_nda_cap_rate_current\' value=\'' . esc_attr( $nda_cap_rate_current ) . '\' placeholder=\'6.0%\'>';
  echo '</div>';

  // Field #8
  $nda_cap_rate_proforma = get_post_meta( $post->ID, '_nda_cap_rate_proforma', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Cap Rate Pro-Forma' .'</label>';
  echo '<input type=\'text\' name=\'_nda_cap_rate_proforma\' value=\'' . esc_attr( $nda_cap_rate_proforma ) . '\' placeholder=\'Cap Rate Pro-Forma\'>';
  echo '</div>';

  // Field #9
  $nda_grm_current = get_post_meta( $post->ID, '_nda_grm_current', true );
  echo '<div class=\'large-4 columns\'><label>'. 'GRM Current' .'</label>';
  echo '<input type=\'text\' name=\'_nda_grm_current\' value=\'' . esc_attr( $nda_grm_current ) . '\' placeholder=\'5\'>';
  echo '</div>';

  // Field #10
  $nda_grm_proforma = get_post_meta( $post->ID, '_nda_grm_proforma', true );
  echo '<div class=\'large-4 columns\'><label>'. 'GRM Pro-Forma' .'</label>';
  echo '<input type=\'text\' name=\'_nda_grm_proforma\' value=\'' . esc_attr( $nda_grm_proforma ) . '\' placeholder=\'11X\'>';
  echo '</div>';

  // Field #11
  $nda_ppsft = get_post_meta( $post->ID, '_nda_ppsft', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Price Per SqFt' .'</label>';
  echo '<input type=\'text\' name=\'_nda_ppsft\' value=\'' . esc_attr( $nda_ppsft ) . '\' placeholder=\'$241\'>';
  echo '</div>';

  // Field #12
  $nda_ppu = get_post_meta( $post->ID, '_nda_ppu', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Price Per Unit' .'</label>';
  echo '<input type=\'text\' name=\'_nda_ppu\' value=\'' . esc_attr( $nda_ppu ) . '\' placeholder=\'$245,000\'>';
  echo '</div>';

  // Field #13
  $nda_building_size = get_post_meta( $post->ID, '_nda_building_size', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Building Size' .'</label>';
  echo '<input type=\'text\' name=\'_nda_building_size\' value=\'' . esc_attr( $nda_building_size ) . '\' placeholder=\'10,400 SF\'>';
  echo '</div>';

  // Field #14
  $nda_lot_size = get_post_meta( $post->ID, '_nda_lot_size', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Lot Size' .'</label>';
  echo '<input type=\'text\' name=\'_nda_lot_size\' value=\'' . esc_attr( $nda_lot_size ) . '\' placeholder=\'25 Ft. x 100 Ft.\'>';
  echo '</div>';

  // Field #15
  $nda_year_built = get_post_meta( $post->ID, '_nda_year_built', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Year Built' .'</label>';
  echo '<input type=\'text\' name=\'_nda_year_built\' value=\'' . esc_attr( $nda_year_built ) . '\' placeholder=\'1991\'>';
  echo '</div>';

  // Field #16
  $nda_total_buildable_sqft = get_post_meta( $post->ID, '_nda_total_buildable_sqft', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Total Buildable SqFt' .'</label>';
  echo '<input type=\'text\' name=\'_nda_total_buildable_sqft\' value=\'' . esc_attr( $nda_total_buildable_sqft ) . '\' placeholder=\'10,400\'>';
  echo '</div>';

  // Field #17
  $nda_price_per_buildable_sqft = get_post_meta( $post->ID, '_nda_price_per_buildable_sqft', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Price Per Buildable SqFt' .'</label>';
  echo '<input type=\'text\' name=\'_nda_price_per_buildable_sqft\' value=\'' . esc_attr( $nda_price_per_buildable_sqft ) . '\' placeholder=\'$250\'>';
  echo '</div>';

  // Field #18
  $nda_far = get_post_meta( $post->ID, '_nda_far', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Far' .'</label>';
  echo '<input type=\'text\' name=\'_nda_far\' value=\'' . esc_attr( $nda_far ) . '\' placeholder=\'4.2\'>';
  echo '</div>';

  // Field #19
  $nda_approved_plans = get_post_meta( $post->ID, '_nda_approved_plans', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Approved Plans' .'</label>';
  echo '<input type=\'text\' name=\'_nda_approved_plans\' value=\'' . esc_attr( $nda_approved_plans ) . '\' placeholder=\'Yes\'>';
  echo '</div>';

  // Field #20
  $nda_existing_finance = get_post_meta( $post->ID, '_nda_existing_finance', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Existing Finance' .'</label>';
  echo '<input type=\'text\' name=\'_nda_existing_finance\' value=\'' . esc_attr( $nda_existing_finance ) . '\' placeholder=\'Yes\'>';
  echo '</div>';

  // Field #21
  $nda_status = get_post_meta( $post->ID, '_nda_status', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Status' .'</label>';
  echo '<input type=\'text\' name=\'_nda_status\' value=\'' . esc_attr( $nda_status ) . '\' placeholder=\'Available, Under Contract, or Closed\'>';
  echo '</div>';

  // Field #22
  $nda_bid_deadline = get_post_meta( $post->ID, '_nda_bid_deadline', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Bid Deadline' .'</label>';
  echo '<input type=\'text\' name=\'_nda_bid_deadline\' value=\'' . esc_attr( $nda_bid_deadline ) . '\' placeholder=\'12/31/2013\'>';
  echo '</div>';

  // Field #23
  $nda_renovated = get_post_meta( $post->ID, '_nda_renovated', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Renovated' .'</label>';
  echo '<input type=\'text\' name=\'_nda_renovated\' value=\'' . esc_attr( $nda_renovated ) . '\' placeholder=\'Yes or No\'>';
  echo '</div>';

  // Field #24
  $nda_list_to_close_ratio = get_post_meta( $post->ID, '_nda_list_to_close_ratio', true );
  echo '<div class=\'large-4 columns\'><label>'. 'List to Close Ratio' .'</label>';
  echo '<input type=\'text\' name=\'_nda_list_to_close_ratio\' value=\'' . esc_attr( $nda_list_to_close_ratio ) . '\' placeholder=\'98%\'>';
  echo '</div>';

  // Field #25
  $nda_number_of_offers = get_post_meta( $post->ID, '_nda_number_of_offers', true );
  echo '<div class=\'large-4 columns\'><label>'. 'Number of Offers' .'</label>';
  echo '<input type=\'text\' name=\'_nda_number_of_offers\' value=\'' . esc_attr( $nda_number_of_offers ) . '\' placeholder=\'17\'>';
  echo '</div>';

  echo'</div></fieldset>';

}
?>