<?php

/**
 * Adds a box to the main column on the Post and Page edit screens.
 */
function ndaproperty_details_add_custom_box() {

    $screens = array( 'post');

    foreach ( $screens as $screen ) {

        add_meta_box(
            'ndaproperty_details_sectionid',
            __( 'Property Details', 'ndaproperty_details_textdomain' ),
            'ndaproperty_details_inner_custom_box',
            $screen
        );
    }
}
add_action( 'add_meta_boxes', 'ndaproperty_details_add_custom_box' );

/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
require_once('property-details-metabox.php');

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function ndaproperty_details_save_postdata( $post_id ) {

  /*
   * We need to verify this came from the our screen and with proper authorization,
   * because save_post can be triggered at other times.
   */

  // Check if our nonce is set.
  if ( ! isset( $_POST['ndaproperty_details_inner_custom_box_nonce'] ) )
    return $post_id;

  $nonce = $_POST['ndaproperty_details_inner_custom_box_nonce'];

  // Verify that the nonce is valid.
  if ( ! wp_verify_nonce( $nonce, 'ndaproperty_details_inner_custom_box' ) )
      return $post_id;

  // If this is an autosave, our form has not been submitted, so we don't want to do anything.
  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
      return $post_id;

  // Check the user's permissions.
  if ( 'page' == $_POST['post_type'] ) {

    if ( ! current_user_can( 'edit_page', $post_id ) )
        return $post_id;

  } else {

    if ( ! current_user_can( 'edit_post', $post_id ) )
        return $post_id;
  }

  /* OK, its safe for us to save the data now. */

  // Sanitize user input.
  $nda_gross_sf = sanitize_text_field( $_POST['_nda_gross_sf']);
  $nda_units = sanitize_text_field( $_POST['_nda_units']);
  $nda_subtype = sanitize_text_field( $_POST['_nda_subtype']);
  $nda_price = sanitize_text_field( $_POST['_nda_price']);
  $nda_gross_rent = sanitize_text_field( $_POST['_nda_gross_rent']);
  $nda_noi = sanitize_text_field( $_POST['_nda_noi']);
  $nda_cap_rate_current = sanitize_text_field( $_POST['_nda_cap_rate_current']);
  $nda_cap_rate_proforma = sanitize_text_field( $_POST['_nda_cap_rate_proforma']);
  $nda_grm_current = sanitize_text_field( $_POST['_nda_grm_current']);
  $nda_grm_proforma = sanitize_text_field( $_POST['_nda_grm_proforma']);
  $nda_ppsft = sanitize_text_field( $_POST['_nda_ppsft']);
  $nda_ppu = sanitize_text_field( $_POST['_nda_ppu']);
  $nda_building_size = sanitize_text_field( $_POST['_nda_building_size']);
  $nda_lot_size = sanitize_text_field( $_POST['_nda_lot_size']);
  $nda_year_built = sanitize_text_field( $_POST['_nda_year_built']);
  $nda_total_buildable_sqft = sanitize_text_field( $_POST['_nda_total_buildable_sqft']);
  $nda_price_per_buildable_sqft = sanitize_text_field( $_POST['_nda_price_per_buildable_sqft']);
  $nda_far = sanitize_text_field( $_POST['_nda_far']);
  $nda_approved_plans = sanitize_text_field( $_POST['_nda_approved_plans']);
  $nda_existing_finance = sanitize_text_field( $_POST['_nda_existing_finance']);
  $nda_status = sanitize_text_field( $_POST['_nda_status']);
  $nda_bid_deadline = sanitize_text_field( $_POST['_nda_bid_deadline']);
  $nda_renovated = sanitize_text_field( $_POST['_nda_renovated']);
  $nda_list_to_close_ratio = sanitize_text_field( $_POST['_nda_list_to_close_ratio']);
  $nda_number_of_offers = sanitize_text_field( $_POST['_nda_number_of_offers']);

  // Update the meta field in the database.
  update_post_meta( $post_id, '_nda_gross_sf', $nda_gross_sf );
  update_post_meta( $post_id, '_nda_units', $nda_units );
  update_post_meta( $post_id, '_nda_subtype', $nda_subtype );
  update_post_meta( $post_id, '_nda_price', $nda_price );
  update_post_meta( $post_id, '_nda_gross_rent', $nda_gross_rent );
  update_post_meta( $post_id, '_nda_noi', $nda_noi );
  update_post_meta( $post_id, '_nda_cap_rate_current', $nda_cap_rate_current );
  update_post_meta( $post_id, '_nda_cap_rate_proforma', $nda_cap_rate_proforma );
  update_post_meta( $post_id, '_nda_grm_current', $nda_grm_current );
  update_post_meta( $post_id, '_nda_grm_proforma', $nda_grm_proforma );
  update_post_meta( $post_id, '_nda_ppsft', $nda_ppsft );
  update_post_meta( $post_id, '_nda_ppu', $nda_ppu );
  update_post_meta( $post_id, '_nda_building_size', $nda_building_size );
  update_post_meta( $post_id, '_nda_lot_size', $nda_lot_size );
  update_post_meta( $post_id, '_nda_year_built', $nda_year_built );
  update_post_meta( $post_id, '_nda_total_buildable_sqft', $nda_total_buildable_sqft );
  update_post_meta( $post_id, '_nda_price_per_buildable_sqft', $nda_price_per_buildable_sqft );
  update_post_meta( $post_id, '_nda_far', $nda_far );
  update_post_meta( $post_id, '_nda_approved_plans', $nda_approved_plans );
  update_post_meta( $post_id, '_nda_existing_finance', $nda_existing_finance );
  update_post_meta( $post_id, '_nda_status', $nda_status );
  update_post_meta( $post_id, '_nda_bid_deadline', $nda_bid_deadline );
  update_post_meta( $post_id, '_nda_renovated', $nda_renovated );
  update_post_meta( $post_id, '_nda_list_to_close_ratio', $nda_list_to_close_ratio );
  update_post_meta( $post_id, '_nda_number_of_offers', $nda_number_of_offers );

}
add_action( 'new_to_publish', 'ndaproperty_details_save_postdata' );
add_action( 'save_post', 'ndaproperty_details_save_postdata' );

class nda_property_details{

    public function __construct($pid) {
        $this->postid = $pid;
    }

    function do_all(){
      $this->gross_sf();
      $this->units();
      $this->subtype();
      $this->price();
      $this->gross_rent();
      $this->noi();
      $this->cap_rate_current();
      $this->cap_rate_proforma();
      $this->grm_current();
      $this->grm_proforma();
      $this->ppsft();
      $this->ppu();
      $this->building_size();
      $this->lot_size();
      $this->year_built();
      $this->total_buildable_sqft();
      $this->price_per_buildable_sqft();
      $this->far();
      $this->approved_plans();
      $this->existing_finance();
      $this->status();
      $this->bid_deadline();
      $this->renovated();
      $this->list_to_close_ratio();
      $this->number_of_offers();
    }

    function gross_sf(){
      $gross_sf = get_post_meta( $this->postid, '_nda_gross_sf', true );
      if ($gross_sf != Null) {
        echo '<p><b>Gross Sqft: </b>' . $gross_sf . '</p><hr/><br>';
      }
    }
    function units(){
      $units = get_post_meta( $this->postid, '_nda_units', true );
      if ($units != Null) {
        echo '<p><b>Units: </b>' . $units . '</p><hr/><br>';
      }
    }
    function subtype(){
      $subtype = get_post_meta( $this->postid, '_nda_subtype', true );
      if ($subtype != Null) {
        echo '<p><b>Sub-type: </b>' . $subtype . '</p><hr/><br>';
      }
    }
    function price(){
      $price = get_post_meta( $this->postid, '_nda_price', true );
      if ($price != Null) {
        echo '<p><b>Price: </b>' . $price . '</p><hr/><br>';
      }
    }
    function gross_rent(){
      $gross_rent = get_post_meta( $this->postid, '_nda_gross_rent', true );
      if ($gross_rent != Null) {
        echo '<p><b>Gross Rent: </b>' . $gross_rent . '</p><hr/><br>';
      }
    }
    function noi(){
      $noi = get_post_meta( $this->postid, '_nda_noi', true );
      if ($noi != Null) {
        echo '<p><b>NOI: </b>' . $noi . '</p><hr/><br>';
      }
    }
    function cap_rate_current(){
      $cap_rate_current = get_post_meta( $this->postid, '_nda_cap_rate_current', true );
      if ($cap_rate_current != Null) {
        echo '<p><b>Cap Rate Current: </b>' . $cap_rate_current . '</p><hr/><br>';
      }
    }
    function cap_rate_proforma(){
      $cap_rate_proforma = get_post_meta( $this->postid, '_nda_cap_rate_proforma', true );
      if ($cap_rate_proforma != Null) {
        echo '<p><b>Cap Rate Proforma: </b>' . $cap_rate_proforma . '</p><hr/><br>';
      }
    }
    function grm_current(){
      $grm_current = get_post_meta( $this->postid, '_nda_grm_current', true );
      if ($grm_current != Null) {
        echo '<p><b>GRM Current: </b>' . $grm_current . '</p><hr/><br>';
      }
    }
    function grm_proforma(){
      $grm_proforma = get_post_meta( $this->postid, '_nda_grm_proforma', true );
      if ($grm_proforma != Null) {
        echo '<p><b>GRM Proforma: </b>' . $grm_proforma . '</p><hr/><br>';
      }
    }
    function ppsft(){
      $ppsft = get_post_meta( $this->postid, '_nda_ppsft', true );
      if ($ppsft != Null) {
        echo '<p><b>Price Per Sqft: </b>' . $ppsft . '</p><hr/><br>';
      }
    }
    function ppu(){
      $ppu = get_post_meta( $this->postid, '_nda_ppu', true );
      if ($ppu != Null) {
        echo '<p><b>Price Per Unit: </b>' . $ppu . '</p><hr/><br>';
      }

    }
    function building_size(){
      $building_size = get_post_meta( $this->postid, '_nda_building_size', true );
      if ($building_size != Null) {
        echo '<p><b>Building Size: </b>' . $building_size . '</p><hr/><br>';
      }
    }
    function lot_size(){
      $lot_size = get_post_meta( $this->postid, '_nda_lot_size', true );
      if ($lot_size != Null) {
        echo '<p><b>Lot Size: </b>' . $lot_size . '</p><hr/><br>';
      }
    }
    function year_built(){
      $year_built = get_post_meta( $this->postid, '_nda_year_built', true );
      if ($year_built != Null) {
        echo '<p><b>Year Built: </b>' . $year_built . '</p><hr/><br>';
      }
    }
    function total_buildable_sqft(){
      $total_buildable_sqft = get_post_meta( $this->postid, '_nda_total_buildable_sqft', true );
      if ($total_buildable_sqft != Null) {
        echo '<p><b>Total Buildable Sqft: </b>' . $total_buildable_sqft . '</p><hr/><br>';
      }
    }
    function price_per_buildable_sqft(){
      $price_per_buildable_sqft = get_post_meta( $this->postid, '_nda_price_per_buildable_sqft', true );
      if ($price_per_buildable_sqft != Null) {
        echo '<p><b>Price Per Buildable Sqft: </b>' . $price_per_buildable_sqft . '</p><hr/><br>';
      }
    }
    function far(){
      $far = get_post_meta( $this->postid, '_nda_far', true );
      if ($far != Null) {
        echo '<p><b>FAR: </b>' . $far . '</p><hr/><br>';
      }
    }
    function approved_plans(){
      $approved_plans = get_post_meta( $this->postid, '_nda_approved_plans', true );
      if ($approved_plans != Null) {
        echo '<p><b>Approved Plans: </b>' . $approved_plans . '</p><hr/><br>';
      }
    }
    function existing_finance(){
      $existing_finance = get_post_meta( $this->postid, '_nda_existing_finance', true );
      if ($existing_finance != Null) {
        echo '<p><b>Existing Finance: </b>' . $existing_finance . '</p><hr/><br>';
      }
    }
    function status(){
      $status = get_post_meta( $this->postid, '_nda_status', true );
      if ($status != Null) {
        echo '<p><b>Status: </b>' . $status . '</p><hr/><br>';
      }
    }
    function bid_deadline(){
      $bid_deadline = get_post_meta( $this->postid, '_nda_bid_deadline', true );
      if ($bid_deadline != Null) {
        echo '<p><b>Bid Deadline: </b>' . $bid_deadline . '</p><hr/><br>';
      }
    }
    function renovated(){
      $renovated = get_post_meta( $this->postid, '_nda_renovated', true );
      if ($renovated != Null) {
        echo '<p><b>Renovated: </b>' . $renovated . '</p><hr/><br>';
      }
    }
    function list_to_close_ratio(){
      $list_to_close_ratio = get_post_meta( $this->postid, '_nda_list_to_close_ratio', true );
      if ($list_to_close_ratio != Null) {
        echo '<p><b>List-to-Close Ratio: </b>' . $list_to_close_ratio . '</p><hr/><br>';
      }
    }
    function number_of_offers(){
      $number_of_offers = get_post_meta( $this->postid, '_nda_number_of_offers', true );
      if ($number_of_offers != Null) {
        echo '<p><b>Number of Offers: </b>' . $number_of_offers . '</p><hr/><br>';
      }
    }
}

?>