<?php
/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
function ndaproperty_brokers_inner_custom_box( $post ) {

  // Add an nonce field so we can check for it later.
  wp_nonce_field( 'ndaproperty_brokers_inner_custom_box', 'ndaproperty_brokers_inner_custom_box_nonce' );

  $blogusers = get_users('orderby=nicename');
  $nda_brokers_json = get_post_meta( get_the_ID(), '_nda_brokers', true );
  $nda_brokers = json_decode($nda_brokers_json);

  echo '<select id="nda-listing-brokers" name="_nda_brokers[]" multiple="multiple">';
  foreach ($blogusers as $user) {
        if ($nda_brokers){
          if (in_array($user->ID, $nda_brokers)) {
            $selected = "selected";
          } else{
            $selected = "";
          }
        }


	        $user_info = get_userdata($user->ID);
	        if ( in_array('author', $user_info->roles) || in_array('contributor', $user_info->roles) || in_array('administrator', $user_info->roles)  ) {
        echo '<option value="' . $user->ID . '"' . $selected . '>' . $user->display_name . '</option>';
        }
  }
  echo '</select>';

  echo "<script>var $ = jQuery;</script>";
  echo "<script> $('#nda-listing-brokers').multiSelect({
                    selectableHeader: \"<div class='custom-header'>Selectable items</div>\",
                    selectionHeader: \"<div class='custom-header'>Selection items</div>\",
                  });
        </script>";
}
?>