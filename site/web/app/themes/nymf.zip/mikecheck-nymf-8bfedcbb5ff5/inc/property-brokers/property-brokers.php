<?php

add_action('admin_init','load_my_script');
function load_my_script() {
    wp_enqueue_style( 'style-multiselect', '/wp-content/themes/digimix/js/multi-select/css/multi-select.css');
    wp_enqueue_script('jquery-multiselect', '/wp-content/themes/digimix/js/multi-select/js/jquery.multi-select.js', array('jquery'), null, false);
    wp_enqueue_script('jquery');
}

/**
 * Adds a box to the main column on the Post and Page edit screens.
 */
function ndaproperty_brokers_add_custom_box() {

    $screens = array( 'post');
    foreach ( $screens as $screen ) {
        add_meta_box(
            'ndaproperty_brokers_sectionid',
            __( 'Property Brokers', 'ndaproperty_brokers_textdomain' ),
            'ndaproperty_brokers_inner_custom_box',
            $screen
        );
    }
}
add_action( 'add_meta_boxes', 'ndaproperty_brokers_add_custom_box' );

/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
require_once locate_template('/inc/property-brokers/property-brokers-metabox.php');

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function ndaproperty_brokers_save_postdata( $post_id ) {

  /*
   * We need to verify this came from the our screen and with proper authorization,
   * because save_post can be triggered at other times.
   */

  // Check if our nonce is set.
  if ( ! isset( $_POST['ndaproperty_brokers_inner_custom_box_nonce'] ) )
    return $post_id;

  $nonce = $_POST['ndaproperty_brokers_inner_custom_box_nonce'];

  // Verify that the nonce is valid.
  if ( ! wp_verify_nonce( $nonce, 'ndaproperty_brokers_inner_custom_box' ) )
      return $post_id;

  // If this is an autosave, our form has not been submitted, so we don't want to do anything.
  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
      return $post_id;

  // Check the user's permissions.
  if ( 'page' == $_POST['post_type'] ) {

    if ( ! current_user_can( 'edit_page', $post_id ) )
        return $post_id;

  } else {

    if ( ! current_user_can( 'edit_post', $post_id ) )
        return $post_id;
  }

  /* OK, its safe for us to save the data now. */

  // Sanitize user input.
  $nda_brokers = Null;
  if (isset($_POST['_nda_brokers'])){
    $nda_brokers = json_encode($_POST['_nda_brokers']);
  }
  // Update the meta field in the database.
  update_post_meta( $post_id, '_nda_brokers', $nda_brokers );

}
add_action( 'new_to_publish', 'ndaproperty_brokers_save_postdata' );
add_action( 'save_post', 'ndaproperty_brokers_save_postdata' );

?>