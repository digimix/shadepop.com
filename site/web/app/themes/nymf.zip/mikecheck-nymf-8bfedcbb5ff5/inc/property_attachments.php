<?php
function property_attachments( $attachments )
{
  $fields         = array(
    array(
      'name'      => 'title',                         // unique field name
      'type'      => 'text',                          // registered field type
      'label'     => __( 'Title', 'attachments' ),    // label to display
      'default'   => 'title',                         // default value upon selection
    ),
    array(
      'name'      => 'caption',                       // unique field name
      'type'      => 'textarea',                      // registered field type
      'label'     => __( 'Caption', 'attachments' ),  // label to display
      'default'   => 'caption',                       // default value upon selection
    ),
    array(
        'name'      => 'option',                            // unique field name
        'type'      => 'select',                            // registered field type
        'label'     => __( 'Option', 'attachments' ),       // label to display
        'meta'      => array(                               // field-specific meta as defined by field class
                        'allow_null'    => false,            // allow null value? (adds 'empty' <option>)
                        'multiple'      => false,            // multiple <select>?
                        'options'       => array(           // the <option>s to use
                              0     => 'Free',
                              1     => 'Email Required',
                              2     => 'Information Required',
                              3     => 'Login Required',
                          )
                      ),
      ),
  );

  $args = array(

    // title of the meta box (string)
    'label'         => 'Property Attachments',

    // all post types to utilize (string|array)
    'post_type'     => array( 'post'),

    // meta box position (string) (normal, side or advanced)
    'position'      => 'normal',

    // meta box priority (string) (high, default, low, core)
    'priority'      => 'high',

    // allowed file type(s) (array) (image|video|text|audio|application)
    'filetype'      => null,  // no filetype limit

    // include a note within the meta box (string)
    'note'          => 'Attach files here!',

    // by default new Attachments will be appended to the list
    // but you can have then prepend if you set this to false
    'append'        => true,

    // text for 'Attach' button in meta box (string)
    'button_text'   => __( 'Attach File', 'attachments' ),

    // text for modal 'Attach' button (string)
    'modal_text'    => __( 'Attach', 'attachments' ),

    // which tab should be the default in the modal (string) (browse|upload)
    'router'        => 'browse',

    // fields array
    'fields'        => $fields,

  );

  $attachments->register( 'property_attachments', $args ); // unique instance name
}

add_action( 'attachments_register', 'property_attachments' );
?>