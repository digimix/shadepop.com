<?php
/*
Plugin Name: NDA Letter of Intent
Plugin URI:
Description: Create and Manage Ad Takeovers
Version: 0.1
Author: Aaron Baker & Adrian Goris
Author URI: http://nda.com/
License: GPL2
*/

function catbanner_styles() {
  if ( is_admin() ) {

    $current_site = site_url();

      wp_register_style( 'nda_dashboard_css', $current_site . '/wp-content/themes/highsociety/css/dashboard.css', false );
      wp_enqueue_style('nda_dashboard_css');

    }
}

add_action('admin_menu','catbanner_styles');
add_action( 'admin_menu', 'register_nda_banner' );

function register_nda_banner(){
    $icon = get_bloginfo('template_directory') . '/inc/category-banner/img/banner-icon.png';
    add_menu_page( 'Banners', 'Banners', 'manage_options', 'nda_banners', 'nda_banner_dashboard', $icon );
}

function nda_banner_preview($banner_hash_id=Null){
  global $wpdb;
  $table_name = $wpdb->prefix . "nda_banner";
  if ($banner_hash_id == Null){
    $takeovers = $wpdb->get_results( "SELECT * FROM " . $table_name . " ORDER BY id DESC" );
  } else{
    $takeovers = $wpdb->get_results( "SELECT * FROM " . $table_name . " WHERE `hash_id`='". $banner_hash_id ."' ORDER BY id DESC" );
  }
  return $takeovers[0];
}

function nda_banner_dbsave() {
  $site_url = site_url();
  $real_referrer = site_url() . '/wp-admin/admin.php?page=add_new_takeover';
  $success_redirect = site_url() . '/wp-admin/admin.php?page=nda_banners';

  if ( $_POST['nda_banner_id'] > 0 ) {
    $id = $_POST['nda_banner_id'];
    nda_banner_update($id);
    return wp_redirect( $success_redirect );
  } else {
    nda_banner_insert();
    return wp_redirect( $success_redirect );
  }
}

// function nda_random_string($length = 10) {
//     $characters = '0123456789-_ABCDEFGHIJKLMNOPQRSTUVWXYZ';
//     $randomString = '';
//     for ($i = 0; $i < $length; $i++) {
//         $randomString .= $characters[rand(0, strlen($characters) - 1)];
//     }
//     return $randomString;
// }

// function nda_banner_postdata(){
//   global $wpdb;
//   $table_name = $wpdb->prefix . "nda_banner";
//   if ($_POST['nda_banner_id'] == 'new'){
//     $rows_affected = $wpdb->insert(
//     $table_name,
//         array(
//           'hash_id'=>$_POST['nda_banner_hash_id'],
//         'property_pid'=>$_POST['nda_banner_property_pid'],
//         'property_name'=>$_POST['nda_banner_property_name'],
//         'property_address'=>$_POST['nda_banner_property_address'],
//         'property_city'=>$_POST['nda_banner_property_city'],
//         'property_state'=>$_POST['nda_banner_property_state'],
//         'property_zip'=>$_POST['nda_banner_property_zip'],
//         'created'=>$_POST['nda_banner_created'],
//         'purchaser'=>$_POST['nda_banner_purchaser'],
//         'email'=>$_POST['nda_banner_email'],
//         'deposit'=>$_POST['nda_banner_deposit'],
//         'purchase_price'=>$_POST['nda_banner_purchase_price'],
//         'financing'=>$_POST['nda_banner_financing'],
//         'due_diligence_period'=>$_POST['nda_banner_due_diligence_period'],
//         'property_condition'=>$_POST['nda_banner_property_condition'],
//         'environmental'=>$_POST['nda_banner_environmental'],
//         'violations'=>$_POST['nda_banner_violations'],
//         'closing_date'=>$_POST['nda_banner_closing_date'],
//         'brokerage_commision'=>$_POST['nda_banner_brokerage_commision'],
//         'closing_date'=>$_POST['nda_banner_closing_date'],
//         'seller_signiture'=>$_POST['nda_banner_seller_signiture'],
//         'output'=>$_POST['nda_banner_buyer_signiture'],
//       )
//     );
//   }
// }

function nda_banner_dashboard(){
  global $wpdb;

  $user = wp_get_current_user();
  $plugin_url = site_url() . '/wp-admin/admin.php?page=add_new_takeover';

  $output = array();

  $wp_categories = get_categories();
  foreach ($wp_categories as $wp_category) {
    if ($wp_category->term_id == 1 && $wp_category->slug == 'uncategorized') {
      continue;
    }
    $output[] = array(
      'title' => $wp_category->name,
      'id' => $wp_category->cat_ID,
      'type' => $wp_category->taxonomy
    );
  }

  $wp_pages = get_posts(array(
      'post_type' => 'page',
      'post_parent' => 0,
      'order' => 'ASC',
      'orderby' => 'menu_order'
    ));
  foreach ($wp_pages as $wp_page) {
        $output[] = array(
          'title' => $wp_page->post_title,
          'id' => $wp_page->ID,
          'type' => 'page'
          );
   }

  // print_r($output);

  echo '<div class="wrap">';
    echo '<h2>Banners</h2>';
  echo '</div>';
    ?>
    <div class="wrap">
      <table class="wp-list-table widefat fixed posts">
        <thead>
        <th width="50">ID</th>
        <th width="150">Type</th>
        <th>Title</th>
        <th>Thumbnail</th>
        <th>Change</th>
      </thead>
      <tbody>
      <?php foreach ($output as $i) { ?>
          <tr>
              <td id="takeover_table_id"><?php echo $i['id'] ; ?></td>
              <td id="takeover_table_start_date"><?php echo $i['type'] ; ?></td>
              <td id="takeover_table_name"><?php echo $i['title']; ?></td>
              <td>Thumbnail</td>
              <td>Change</td>
          </tr>
      <?php } ?>
        </tbody>
      </table>
    </div>
<?php }

function nda_banner_post($id){
    global $wpdb;
    $table_name = $wpdb->prefix . "nda_banner";
    $takeover = $wpdb->get_results( "SELECT * FROM " . $table_name . " WHERE id='" . $id . "'"  );
    return $takeover;
}