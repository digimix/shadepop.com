<?php 
require_once( '../../../wp-load.php' ); 

function nda_loi_dbsave() {
	$site_url = site_url();	
	$real_referrer = site_url() . '/wp-admin/admin.php?page=add_new_takeover';
	$success_redirect = site_url() . '/wp-admin/admin.php?page=nda_lois';

	if ( $_POST['nda_loi_id'] > 0 ) {
		$id = $_POST['nda_loi_id'];
		nda_loi_update($id);
		return wp_redirect( $success_redirect );
	} else {
		nda_loi_insert();
		return wp_redirect( $success_redirect );
	}
}

function nda_loi_postdata(){
	global $wpdb;
	
	$_POST['nda_loi_pid'];
	$_POST['nda_loi_name'];
	$_POST['nda_loi_date'];
	$_POST['nda_loi_address'];
	$_POST['nda_loi_city'];
	$_POST['nda_loi_state'];
	$_POST['nda_loi_zip'];
	$_POST['nda_loi_purchaser'];
	$_POST['nda_loi_email'];
	$_POST['nda_loi_deposit'];
	$_POST['nda_loi_purchase_price'];
	$_POST['nda_loi_financing'];
	$_POST['nda_loi_due_diligence_period'];
	$_POST['nda_loi_property_condition'];
	$_POST['nda_loi_environmental'];
	$_POST['nda_loi_violations'];
	$_POST['nda_loi_closing_date'];
	$_POST['nda_loi_brokerage_commision'];
	$_POST['nda_loi_closing_date'];
	$_POST['nda_loi_seller_signiture'];
	$_POST['output'];


}


function nda_loi_insert(){

	global $wpdb;

	$name = $_POST['nda_loi_name'];
	$active_state = $_POST['nda_active_state'];
	$bg_url = $_POST['nda_bg_url'];
	$bg_color = $_POST['nda_bg_color'];
	$bg_click = $_POST['nda_bg_click'];
	$bg_trackingpixel = $_POST['nda_bg_trackingpixel'];
	$bg_position = $_POST['nda_bg_position'];
	$margin = $_POST['nda_margin'];
	$pushdown = stripslashes($_POST['nda_pushdown']);
	$leaderboard = stripslashes($_POST['nda_leaderboard']);
	$sidebar = stripslashes($_POST['nda_sidebar']);
	$mediumad = stripslashes($_POST['nda_mediumad']);
	$mobilead = stripslashes($_POST['nda_mobilead']);
	$leaderboard_btf = stripslashes($_POST['nda_leaderboard_btf']);
	$sidebar_btf = stripslashes($_POST['nda_sidebar_btf']);
	$mediumad_btf = stripslashes($_POST['nda_mediumad_btf']);
	$mobilead_btf = stripslashes($_POST['nda_mobilead_btf']);
	$special_key = stripslashes($_POST['nda_special_key']);	
	$css = stripslashes($_POST['nda_loi_css']);
	$takeover_categories = $_POST['nda_loi_categories'];
	$takeover_categories = explode(', ', $takeover_categories);
	$takeover_categories = json_encode($takeover_categories);
	$takeover_posts = $_POST['nda_loi_posts'];
	$takeover_posts = explode(', ', $takeover_posts);	
	$takeover_posts = json_encode($takeover_posts);
	$start_date = $_POST['nda_start_date'];
	$end_date = $_POST['nda_end_date'];




	$table_name = $wpdb->prefix . "nda_loi";


	$rows_affected = $wpdb->insert( 
		$table_name, 
   		array( 
			'name' => $name,
			'active_state' => $active_state,
			'bg_url' => $bg_url,
			'bg_color' => $bg_color,
			'bg_click' => $bg_click,
			'bg_trackingpixel' => $bg_trackingpixel,
			'bg_position' => $bg_position,
			'margin' => $margin,
			'pushdown' => $pushdown,
			'leaderboard' => $leaderboard,
			'sidebar' => $sidebar,
			'mediumad' => $mediumad,
			'mobilead' => $mobilead,
			'leaderboard_btf' => $leaderboard_btf,
			'sidebar_btf' => $sidebar_btf,
			'mediumad_btf' => $mediumad_btf,
			'mobilead_btf' => $mobilead_btf,
			'special_key' => $special_key,
			'categories' => $takeover_categories,
			'posts' => $takeover_posts,
			'css' => $css,
			'start_date' => $start_date,
			'end_date' => $end_date			
		)
	);

}




function nda_loi_update($id){

	global $wpdb;

	$name = $_POST['nda_loi_name'];
	$active_state = $_POST['nda_active_state'];
	$bg_url = $_POST['nda_bg_url'];
	$bg_color = $_POST['nda_bg_color'];
	$bg_click = $_POST['nda_bg_click'];
	$bg_trackingpixel = $_POST['nda_bg_trackingpixel'];
	$bg_position = $_POST['nda_bg_position'];
	$margin = $_POST['nda_margin'];	
	$pushdown = stripslashes($_POST['nda_pushdown']);
	$leaderboard = stripslashes($_POST['nda_leaderboard']);
	$sidebar = stripslashes($_POST['nda_sidebar']);
	$mediumad = stripslashes($_POST['nda_mediumad']);
	$mobilead = stripslashes($_POST['nda_mobilead']);
	$leaderboard_btf = stripslashes($_POST['nda_leaderboard_btf']);
	$sidebar_btf = stripslashes($_POST['nda_sidebar_btf']);
	$mediumad_btf = stripslashes($_POST['nda_mediumad_btf']);
	$mobilead_btf = stripslashes($_POST['nda_mobilead_btf']);
	$special_key = stripslashes($_POST['nda_special_key']);			
	$css = stripslashes($_POST['nda_loi_css']);
	$takeover_categories = $_POST['nda_loi_categories'];
	$takeover_categories = explode(', ', $takeover_categories);
	$takeover_categories = json_encode($takeover_categories);
	$takeover_posts = $_POST['nda_loi_posts'];
	$takeover_posts = explode(', ', $takeover_posts);	
	$takeover_posts = json_encode($takeover_posts);
	$start_date = $_POST['nda_start_date'];
	$end_date = $_POST['nda_end_date'];




	$table_name = $wpdb->prefix . "nda_loi";


	$rows_affected = $wpdb->update( 
		$table_name, 
   		array( 
			'name' => $name,
			'active_state' => $active_state,
			'bg_url' => $bg_url,
			'bg_color' => $bg_color,
			'bg_click' => $bg_click,
			'bg_trackingpixel' => $bg_trackingpixel,
			'bg_position' => $bg_position,
			'margin' => $margin,			
			'pushdown' => $pushdown,
			'leaderboard' => $leaderboard,
			'sidebar' => $sidebar,
			'mediumad' => $mediumad,
			'mobilead' => $mobilead,
			'leaderboard_btf' => $leaderboard_btf,
			'sidebar_btf' => $sidebar_btf,
			'mediumad_btf' => $mediumad_btf,
			'mobilead_btf' => $mobilead_btf,
			'special_key' => $special_key,			
			'categories' => $takeover_categories,
			'posts' => $takeover_posts,	
			'css' => $css,
			'start_date' => $start_date,
			'end_date' => $end_date			
		),
		array(
			'id' => $id
			)
	);

}

nda_loi_postdata();

?>