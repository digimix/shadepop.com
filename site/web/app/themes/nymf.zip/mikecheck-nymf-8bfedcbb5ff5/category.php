<?php
	use Roots\Sage\Titles;
	use Roots\Sage\Extras;

	//$cat_id = get_query_var( 'cat' );
	$current_cat = get_category( get_query_var( 'cat' ) );
	$cat_id = $current_cat->cat_ID;
	$cat_name = $current_cat->name;
	$cat_slug = $current_cat->slug;

	if (get_query_var( 'district') !== '') {
		$district_slug = get_query_var( 'district' );
		$current_district = get_term_by( 'slug', $district_slug, 'district');
	}
	?>

	<?php get_template_part('templates/page', 'header'); ?>

<!--
 <div class="page-header hero parallax bkb-area">
	<h1><?= Titles\title(); ?>
	<?php if (get_query_var( 'district') !== '') {
		echo ': <span class="highlight bold" style="text-transform: capitalize;">'. $current_district->name .'</span>';
	} ?></h1>
	<p class="subtitle">Updated in Real Time</p>
	<?php if (term_description() !== '') {?>
	<div class=" container">
		<div class="summary">
		<?php echo term_description(); ?>
		</div>
	</div>
	<?php } ?>
</div>
-->

<section>

	<div class="section-header">
		<div class="container">
			<h4>Filter Listings</h4>
		</div>
	</div>
	<div class="post-filters" style="background: #1E3667;padding-top: 20px;">
		<div class="container">

			<form class="row form-inline" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">

				<div class="form-group col-xs-12 col-sm-3">
					<label class="sr-only light-text" for="FilterDistrict">Password</label>
					<select class="col-sm-3 form-control " name="category_name" onchange="this.form.submit();">
					<?php
					$args = array(
						'hide_empty'       => 1,
						'orderby'          => 'count',
						'order'            => 'DESC'
					);
					$categories = get_categories($args);

					$cat_options = array();
					foreach ($categories as $category) {
						//dynamically defining an associative array with dynamic key and dynamic value
						//$cat_options += array($category->category_nicename => $category->cat_name . " (" . $category->category_count . ") ");
						$cat_options += array($category->category_nicename => $category->cat_name);
					}
					foreach( $cat_options as $value => $label ) {
						if ($cat_slug == $value) {
							echo "<option selected value='$value'>$label</option>";
						} else {
							echo "<option value='$value'>$label</option>";
						}
					}
					?>
				</select>
			</div>

			<!--
			<?php
			$args = array(
				'show_option_none' => __( 'Select category' ),
				'show_count'       => 1,
				'orderby'          => 'name',
				'echo'             => 0,
			);
			?>

			<?php $select  = wp_dropdown_categories( $args ); ?>
			<?php $replace = "<select$1 onchange='return this.form.submit()'>"; ?>
			<?php $select  = preg_replace( '#<select([^>]*)>#', $replace, $select ); ?>

			<?php echo $select; ?>
			-->


			<?php
			global $wp_query;
			$tax = 'district'; // taxonomy name
			//**THIS SET WILL PLUCK ALL TAXONOMY TERMS OF CURRENT QUERY OF POSTS
			//*
			//$post_ids = wp_list_pluck( $wp_query->posts, 'ID' );
			//$termobjs = wp_get_object_terms( $post_ids, 'district' );
			//$brandlist = array_unique( wp_list_pluck( $termobjs, 'term_id' ) ); // distinct term names

			//**THIS SET WILL PLUCK ALL TAXONOMY TERMS
			//*
			// esc_url( remove_query_arg( $tax,  $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]) );
			$args = array(
				'hide_empty'       => 1,
				'orderby'          => 'name'
			);



			$brandlist = get_terms($tax, $args);
			?>
			<div class="form-group col-xs-12 col-sm-3">
				<label class="sr-only light-text" for="FilterDistrict">Password</label>
				<select id="FilterDistrict" class="form-control" name="<?= $tax; ?>" onchange="this.form.submit();">
					<!-- <option value="0" onchange="window.location.href='<?php echo esc_url(remove_query_arg('district',$_SERVER['REQUEST_URI'])); ?>'">All <?php echo esc_attr(__('Districts')); ?></option> -->

					<?php
					$term_options = array();

					//foreach ($brandlist as $brand_id) {
					foreach ($brandlist as $brand) {
						//$brand = get_term_by('id', $brand_id, 'district');
						// $term_options += array($brand->slug => $brand->name . ' (' . $brand->count . ')');
						$term_options += array($brand->slug => $brand->name);

					}

					//foreach ($terms as $term) {
						//$term_options += array($term->slug => $term->name);
					//}

					// $cat_lists = join( ', ', $cat_list );

					foreach( $term_options as $value => $label ) {
						if ( $_GET[$tax] ==  $value ) {
							echo "<option ".selected( $_GET[$tax], $value )." value='$value'>$label</option>";
						} else if (get_query_var( 'district') == $value) {
							echo "<option ".selected( get_query_var( 'district'), $value )." value='$value'>$label</option>";
						}  else {
							echo "<option value='$value'>$label</option>";
						}
					}
					?>
				</select>
			</div>

			<!-- <a href="<?php echo esc_url(remove_query_arg('district',$_SERVER['REQUEST_URI'])); ?>">TEST REFRESH</a> -->

			<!--
				<select name="orderby">
					<?php
					$orderby_options = array(
					'post_date' => 'Order By Date',
					//'post_title' => 'A - Z',
					'rand' => 'Random Order',
					);
					foreach( $orderby_options as $value => $label ) {
					echo "<option ".selected( $_GET['orderby'], $value )." value='$value'>$label</option>";
					}
					?>
				</select>
			-->



			<div class="form-group col-xs-12 col-sm-6">
				<div class="pull-right">
				<label class="light-text" for="SortOrder" >Sort Results by:</label>
				<select id="SortOrder" class="form-control" name="order" onchange="this.form.submit();">
					<?php
					$order_options = array(
					'DESC' => 'Newest',
					'ASC' => 'Oldest',
					);
					foreach( $order_options as $value => $label ) {
					echo "<option ".selected( $_GET['order'], $value )." value='$value'>$label</option>";
					}
					?>
				</select>
				</div>
			</div>

			<input class="hidden" type='submit' value='Filter!'>
		</form>
		</div>
	</div>

</div>




	<div class="price-slider">
		<div class="container">
			<div id="price-filter" class="panel-collapse collapse in" style="height: auto;">
				<div id="price-range" data-slide-last-val="15000000" data-slide-step="500000" data-def-currency="$" data-max-price="15000000" data-min-price="<?= Extras\min_meta_value(); ?>" class="ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all" aria-disabled="false">
					<div class="ui-slider-range ui-widget-header ui-corner-all"></div>
					<a class="ui-slider-handle ui-state-default ui-corner-all" href="#" style="left: 10%;"></a><a class="ui-slider-handle ui-state-default ui-corner-all" href="#" style="left: 80%;"></a>
				</div>
				<br>
				<span class="price-label min-price-label pull-left beta">&nbsp;</span>
				<span class="price-label max-price-label pull-right beta">&nbsp;</span>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>


	<div class="section-header" style="background-color: #1B305A;">
		<div class="container">
			<p class="light-text" style="text-transform: none;margin-top:1.375em;">
				Listing inventory for <span class="highlight bold"><?php echo $cat_name; ?></span>
				<?php if (get_query_var( 'district') !== '') {
						echo ' in <span class="highlight bold" style="text-transform: capitalize;">'. $current_district->name .'</span> ';
					} ?>
				from <span class="bold price-label min-price-label highlight">&nbsp;</span> - <span class="price-label max-price-label highlight bold">&nbsp;</span>
			</p>
		</div>
	</div>


</section>


<div class="container">
<?php if (!have_posts()) : ?>
  <div class="alert alert-warning">
    <?php _e('Sorry, no results were found.<br/>Please refine your search and try again.', 'roots'); ?>
  </div>
  <?php get_search_form(); ?>
<?php endif; ?>


<?php //$current_url = esc_url($_SERVER['REQUEST_URI']);  var_dump(parse_url($current_url, PHP_URL_QUERY)); ?>

<div class="listings-archive row">
	<ul class="col-4 listings">
<?php while (have_posts()) : the_post(); ?>
  <?php get_template_part('templates/content', get_post_format()); ?>
<?php endwhile; ?>
	</ul>
</div>

</div>
<div class="container">
<?php if ($wp_query->max_num_pages > 1) : ?>
  <nav class="post-nav">
    <ul class="pager">
      <li class="previous"><?php next_posts_link(__('&larr; More Listings', 'roots')); ?></li>
      <li class="next"><?php previous_posts_link(__('Previous Listings &rarr;', 'roots')); ?></li>
    </ul>
  </nav>
<?php endif; ?>
</div>