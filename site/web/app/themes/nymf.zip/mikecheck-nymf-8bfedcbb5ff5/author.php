<?php
use Roots\Sage\Extras;

$curauth = (isset($_GET['author_name'])) ? get_user_by('slug', $author_name) : get_userdata(intval($author));
$authorid = $curauth->ID;
?>
<div class="bg-city border-bottom hidden-xs"></div>
<!--
<div class="page-header row">
	<div class="container">
		<div class="col-sm-9 col-sm-offset-3" style="height:130px;">
			<h1><?php echo $curauth->display_name;?></h1>
			<p class="subtitle">Listing Agent @ The Rinney Group</p>
	<?php if (esc_html( $curauth->_nda_work_phone ) !='') {
		echo '<p class="m0"><i class="fa fa-phone"></i> ' .esc_html( $curauth->_nda_work_phone ) . '</p>';
	}
	if (esc_html( $curauth->user_email ) !='') {
		echo '<p class="m0"><i class="fa fa-envelope"></i> ' .esc_html( $curauth->user_email ) . '</p>';
	}?>
		</div>
	</div>
</div>
-->
<?php // get_template_part('templates/page', 'header'); ?>


<div class="container">
	<div class="row">
		<div class="">
			<div class="col-sm-5 col-md-3 avatar-wrapper">
				<figure>
					<?php
					$avatar_url = $curauth->_nda_user_avatar;
					$avatar_id = attachment_url_to_postid($avatar_url);

					$avatar =  Extras\featured_url_by_id($avatar_id, 'square-medium'); ?>
					<img class="avatar" src="<?= $avatar;?>">
				</figure>
			</div>
			<div class="page-header col-sm-7 col-md-9">
				<h1 class="serif"><?php echo $curauth->display_name;?></h1>
				<div class="row">
					<div class="col-sm-12 col-md-6">
						<p class="subtitle"><?php echo $curauth->_nda_job_title;?> @ <?php echo $curauth->_nda_user_company;?></p>
					</div>
					<div class="col-sm-12 col-md-6 listedby">
						<?php if (esc_html( $curauth->_nda_work_phone ) !='') {
							echo '<p class="m0"><i class="fa fa-fw fa-phone gold"></i> ' .esc_html( $curauth->_nda_work_phone ) . '</p>';
						}
						if (esc_html( $curauth->user_email ) !='') {
							echo '<p class="m0"><i class="fa fa-fw fa-envelope gold"></i> <a title="Send an email to '.$curauth->display_name.' " href="mailto:'.esc_html( $curauth->user_email ) .'">' .esc_html( $curauth->user_email ) . '</a></p>';
						}?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!-- // end container -->

<div class="container">
	<div class="entry-content col-sm-12">
		<p><?php echo wpautop(get_the_author_meta( 'description', $authorid )); ?></p>
	</div>

</div> <!-- // end container -->

<section>
	<div class="section-header col-sm-12" >
		<div class="container">
			<h4><?php echo $curauth->display_name;?>'s Latest Listings <small class="serif italic" style="text-transform:none;"><a href="/on-market/">See all listings <i class="arrrows">r</i></a></small></h4>
		</div>
	</div>
	<div class="related-listings col-sm-12">
	<ul class="related col-6">
	<?php
	$args = array(
		'posts_per_page' => 6,
		//'category'=> 6,
		'meta_query' => array(
			'relation' => 'OR',
			array(
				'key' => '_nda_listing_brokers',
	            'value'    => $authorid,
	            'compare' => 'LIKE',
			),
			array(
				'key' => '_nda_brokers',
	            'value'    => $authorid,
	            'compare' => 'LIKE',
			),
		)
	 );
	$agent_posts = get_posts( $args );?>

	<?php foreach ( $agent_posts as $post ) :
		setup_postdata( $post ); ?>
		<?php $price = get_post_meta( $post->ID, '_nda_price', true ); ?>
		<?php if (has_post_thumbnail()) { ?>
			<li>
				<article>
					<a href="<?php the_permalink(); ?>">
						<figure>
							<?php the_post_thumbnail('listing-archive', array('class'=>'h100 w100')); ?>
							<figcaption class="serif">
								<?php
									$title = get_the_title();
									$title = preg_replace('/Avenue,/', 'Avenue', $title);
									$title = preg_replace('/Avenue/', 'Ave,<br/>', $title);
									$title = preg_replace('/Street,/', 'Street', $title);
									$title = preg_replace('/Street/', 'St,<br/>', $title);
									$title = preg_replace('/Place,/', 'Place', $title);
									$title = preg_replace('/Place/', 'Place,<br/>', $title);
									$title = preg_replace('/Blvd,/', 'Blvd', $title);
									$title = preg_replace('/Blvd/', 'Blvd,<br/>', $title);
									$title = preg_replace('/Parkway,/', 'Parkway', $title);
									$title = preg_replace('/Parkway/', 'Parkway,<br/>', $title);
									$price = preg_replace('~\.0+$~','',$price);
								?>
								<h3><?php echo $title; ?></h3>

								<p><em><?php if ($price > 0) { echo '$' . $price;} else { echo 'See Listing Agent';} ?></em></p>
							</figcaption>
						</figure>
					</a>
				</article>
			</li>
		<?php
		} ?>
		<?php // get_template_part('templates/content', get_post_format()); ?>
	<?php endforeach;
	wp_reset_postdata(); ?>
	</ul>
	</div>
</section>

<!--
<?php if (!have_posts()) : ?>
  <div class="alert alert-warning">
    <?php _e('Sorry, no results were found.', 'roots'); ?>
  </div>
  <?php get_search_form(); ?>
<?php endif; ?>

<div class="listings-archive row">
<?php while (have_posts()) : the_post(); ?>
  <?php get_template_part('templates/content', get_post_format()); ?>
<?php endwhile; ?>
</div>

<?php if ($wp_query->max_num_pages > 1) : ?>
  <nav class="post-nav">
    <ul class="pager">
      <li class="previous"><?php next_posts_link(__('&larr; More Listings', 'roots')); ?></li>
      <li class="next"><?php previous_posts_link(__('Previous Listings &rarr;', 'roots')); ?></li>
    </ul>
  </nav>
<?php endif; ?>
-->
