<?php
/*
Template Name: Team
*/

use Roots\Sage\Extras;
?>

<?php while (have_posts()) : the_post(); ?>
	<?php get_template_part('templates/page', 'header'); ?>
	<div class="container">
		<?php the_post_thumbnail('large', array('class'=>'w100 hauto banner-img'));?>
		<div style="padding:2% 15% 4%;">
		  <?php get_template_part('templates/content', 'page'); ?>
		</div>
	</div>
<?php endwhile; ?>

<div class="shaded-light" style="padding: 40px 0;">
	<div class="container">
		<ul class="col-4 agents">
			<?php
			$blogusers = get_users( 'blog_id=1&orderby=nicename&role=author' );
			// Array of WP_User objects.
			foreach ( $blogusers as $user ) { ?>
			<li class="agent">
				<a href="<?php echo get_author_posts_url( $user->ID ); ?>">
					<figure>
						<?php
						$avatar_url = $user->_nda_user_avatar;
						$avatar_id = attachment_url_to_postid($avatar_url);

						$avatar =  Extras\featured_url_by_id($avatar_id, 'square-medium'); ?>
						<img class="avatar" src="<?= $avatar;?>">
					</figure>


					 <?php //echo get_wp_user_avatar($user->ID, 'square-medium'); ?>
					<h5 class="caps m0"><?php echo esc_html( $user->display_name ); ?></h5>
					<div class="hidden-xs">
					<?php if (esc_html( $user->_nda_work_phone ) !='') {
						echo '<p class="m0"><i class="fa fa-phone"></i> ' .esc_html( $user->_nda_work_phone ) . '</p>';
					}
					if (esc_html( $user->user_email ) !='') {
						echo '<p class="m0"><i class="fa fa-envelope"></i> ' .esc_html( $user->user_email ) . '</p>';
					}
					?>
					</div>
				</a>
			</li>
			<?php } ?>
		</ul>
	</div>
</div>