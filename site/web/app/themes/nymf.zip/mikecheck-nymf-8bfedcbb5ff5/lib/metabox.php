<?php
/**
 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the CMB2 directory)
 *
 * Be sure to replace all instances of 'nda_' with your project's prefix.
 * http://nacin.com/2010/05/11/in-wordpress-prefix-everything/
 *
 * @category YourThemeOrPlugin
 * @package  Demo_CMB2
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/WebDevStudios/CMB2
 */

/**
 * Get the bootstrap! If using the plugin from wordpress.org, REMOVE THIS!
 */

if ( file_exists( dirname( __FILE__ ) . '/cmb2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/cmb2/init.php';
} elseif ( file_exists( dirname( __FILE__ ) . '/CMB2/init.php' ) ) {
	require_once dirname( __FILE__ ) . '/CMB2/init.php';
}

/**
 * Conditionally displays a metabox when used as a callback in the 'show_on_cb' cmb2_box parameter
 *
 * @param  CMB2 object $cmb CMB2 object
 *
 * @return bool             True if metabox should show
 */
function nda_show_if_front_page( $cmb ) {
	// Don't show this metabox if it's not the front page template
	if ( $cmb->object_id !== get_option( 'page_on_front' ) ) {
		return false;
	}
	return true;
}

/**
 * Conditionally displays a field when used as a callback in the 'show_on_cb' field parameter
 *
 * @param  CMB2_Field object $field Field object
 *
 * @return bool                     True if metabox should show
 */
function nda_hide_if_contact_page( $cmb ) {
	// Don't show this field if not in the cats category
	if ( $cmb->object_id == 445 ) {
		return false;
	}
	return true;
}


/**
 * Conditionally displays a field when used as a callback in the 'show_on_cb' field parameter
 *
 * @param  CMB2_Field object $field Field object
 *
 * @return bool                     True if metabox should show
 */
function nda_hide_if_no_cats( $field ) {
	// Don't show this field if not in the cats category
	if ( ! has_tag( 'cats', $field->object_id ) ) {
		return false;
	}
	return true;
}


function cmb2_get_user_options( $query_args ) {

    $args = wp_parse_args( $query_args, array(

		'fields' => array( 'user_login'),
    ) );

    $users = get_users('orderby=meta_value&meta_key=last_name');

    $user_options = array();
    if ( $users ) {
        foreach ( $users as $user ) {
	        $user_info = get_userdata($user->ID);
	        if ( in_array('author', $user_info->roles) || in_array('contributor', $user_info->roles) || in_array('administrator', $user_info->roles)  ) {
				if ( !in_array($user->ID, [86,89, 201]) ) {
		        	$user_options[ $user->ID ] = $user_info->first_name . ' '  . $user_info->last_name;
				}
            }
        }
    }

    return $user_options;
}


/**
 * Gets a number of posts and displays them as options
 * @param  array $query_args Optional. Overrides defaults.
 * @return array             An array of options that matches the CMB2 options array
 */
function cmb2_get_dlm_options( $query2_args ) {

    $args = wp_parse_args( $query2_args, array(
        'post_type'   => 'dlm_download',
        'numberposts' => -1,
    ) );

    $posts = get_posts( $args );

    $post_options = array();
    if ( $posts ) {
        foreach ( $posts as $post ) {
          $post_options[ $post->ID ] = $post->post_title;
        }
    }

    return $post_options;
}


/**
 * Metabox for Page Template
 * @author Kenneth White
 * @link https://github.com/WebDevStudios/CMB2/wiki/Adding-your-own-show_on-filters
 *
 * @param bool $display
 * @param array $meta_box
 * @return bool display metabox
 */
function be_metabox_show_on_template( $display, $meta_box ) {
    if ( ! isset( $meta_box['show_on']['key'], $meta_box['show_on']['value'] ) ) {
        return $display;
    }

    if ( 'template' !== $meta_box['show_on']['key'] ) {
        return $display;
    }

    $post_id = 0;

    // If we're showing it based on ID, get the current ID
    if ( isset( $_GET['post'] ) ) {
        $post_id = $_GET['post'];
    } elseif ( isset( $_POST['post_ID'] ) ) {
        $post_id = $_POST['post_ID'];
    }

    if ( ! $post_id ) {
        return false;
    }

    $template_name = get_page_template_slug( $post_id );
    $template_name = ! empty( $template_name ) ? substr( $template_name, 0, -4 ) : '';

    // See if there's a match
    return in_array( $template_name, (array) $meta_box['show_on']['value'] );
}
add_filter( 'cmb2_show_on', 'be_metabox_show_on_template', 10, 2 );



/**
 * Include metabox on front page
 * @author Ed Townend
 * @link https://github.com/WebDevStudios/CMB2/wiki/Adding-your-own-show_on-filters
 *
 * @param bool $display
 * @param array $meta_box
 * @return bool display metabox
 */
function ed_metabox_include_front_page( $display, $meta_box ) {
    if ( ! isset( $meta_box['show_on']['key'] ) ) {
        return $display;
    }

    if ( 'front-page' !== $meta_box['show_on']['key'] ) {
        return $display;
    }

    $post_id = 0;

    // If we're showing it based on ID, get the current ID
    if ( isset( $_GET['post'] ) ) {
        $post_id = $_GET['post'];
    } elseif ( isset( $_POST['post_ID'] ) ) {
        $post_id = $_POST['post_ID'];
    }

    if ( ! $post_id ) {
        return $display;
    }

    // Get ID of page set as front page, 0 if there isn't one
    $front_page = get_option( 'page_on_front' );

    // there is a front page set and we're on it!
    return $post_id == $front_page;
}
add_filter( 'cmb2_show_on', 'ed_metabox_include_front_page', 10, 2 );

/**
 * Conditionally displays a message if the $post_id is 2
 *
 * @param  array             $field_args Array of field parameters
 * @param  CMB2_Field object $field      Field object
 */
function nda_before_row_if_2( $field_args, $field ) {
	if ( 2 == $field->object_id ) {
		echo '<p>Testing <b>"before_row"</b> parameter (on $post_id 2)</p>';
	} else {
		echo '<p>Testing <b>"before_row"</b> parameter (<b>NOT</b> on $post_id 2)</p>';
	}
}



add_action( 'cmb2_init', 'nda_register_featured_prop_metabox' );
/**
 * Hook in and add a metabox that only appears on the 'About' page
 */
function nda_register_featured_prop_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_nda_featured_prop_';

	/**
	 * Metabox to be displayed on a single page ID
	 */
	$cmb_featured_prop = new_cmb2_box( array(
		'id'           => $prefix . 'metabox',
		'title'        => __( 'Featured Listings', 'cmb2' ),
		'object_types' => array( 'page' ), // Post type
		//'show_on'      => array( 'key' => 'page-template', 'value' => array( 'template-standard.php', ), ), // Specific post IDs to display this metabox
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		'show_on_cb'   => 'nda_show_if_front_page',
	) );

	$cmb_featured_prop->add_field( array(
	    'name'    => 'Featured Listings',
	    //'desc'    => 'field description (optional)',
	    'id'      => $prefix . 'listings',
	    'type'    => 'pw_multiselect',
	    'options' => cmb2_get_dlm_options(
	    	array(
	    	'post_type' => 'post',
	    	'numberposts' => -1,
/*
		    'tax_query' => array(
		        array(
		            'taxonomy' => 'dlm_download_category',
		            'field'    => 'id',
		            'terms'    => array(27),
		            'operator' => 'NOT IN',
		        ),
		    ),
*/
	    )),
	) );
}




add_action( 'cmb2_init', 'nda_register_offices_group_field_metabox' );
/**
 * Hook in and add a metabox to demonstrate repeatable grouped fields
 */
function nda_register_offices_group_field_metabox() {
	// Start with an underscore to hide fields from custom fields list
	$prefix = '_nda_offices_';
	/**
	 * Repeatable Field Groups
	 */
	$cmb_offices = new_cmb2_box( array(
		'id'           => $prefix . 'metabox',
		'title'        => __( 'Offices', 'cmb2' ),
		'object_types' => array( 'page', ),
		'show_on'      => array( 'key' => 'page-template', 'value' => array( 'template-contact.php', ), ), // Specific post IDs to display this metabox
	) );
	// $group_field_id is the field id string, so in this case: $prefix . 'demo'
	$office_field_id = $cmb_offices->add_field( array(
		'id'          => $prefix . 'group',
		'type'        => 'group',
		'description' => __( 'Generates reusable form entries', 'cmb2' ),
		'options'     => array(
			'group_title'   => __( 'Office Entry {#}', 'cmb2' ), // {#} gets replaced by row number
			'add_button'    => __( 'Add Another Office Entry', 'cmb2' ),
			'remove_button' => __( 'Remove Office Entry', 'cmb2' ),
			'sortable'      => true, // beta
		),
	) );
	/**
	 * Group fields works the same, except ids only need
	 * to be unique to the group. Prefix is not needed.
	 *
	 * The parent field's id needs to be passed as the first argument.
	 */
	$cmb_offices->add_group_field( $office_field_id, array(
		'name'        => __( 'Title', 'cmb2' ),
		'id'          => 'title',
		'type'        => 'text_medium',
	) );
	$cmb_offices->add_group_field( $office_field_id, array(
		'name'        => __( 'Lead', 'cmb2' ),
		'id'          => 'lead',
		'description' => __( 'Select the lead broker', 'cmb2' ),
		'type'        => 'pw_select',
		'options' => cmb2_get_user_options( array( 'fields' => array( 'user_nicename' ), 'role' => 'admin', ) ),
	) );

	$cmb_offices->add_group_field( $office_field_id, array(
		'name'       => __( 'Office Address', 'cmb2' ),
		'id'         => 'address',
		'type'       => 'address',
		// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );
	$cmb_offices->add_group_field( $office_field_id, array(
		'name'        => __( 'Phone (Main)', 'cmb2' ),
		'id'          => 'phone',
		'type'        => 'text_medium',
		//'repeatable' => true,
	) );
	$cmb_offices->add_group_field( $office_field_id, array(
		'name'        => __( 'Phone (Direct)', 'cmb2' ),
		'id'          => 'phone_direct',
		'type'        => 'text_medium',
		//'repeatable' => true,
	) );

	$cmb_offices->add_group_field( $office_field_id, array(
		'name' => __( 'Email', 'cmb2' ),
		'id'   => 'email',
		'type' => 'text_email',
	) );
	$cmb_offices->add_group_field( $office_field_id, array(
		'name' => __( 'Image', 'cmb2' ),
		'id'   => 'image',
		'type' => 'file',
	) );
}






add_action( 'cmb2_init', 'nda_register_subtitle_metabox' );
/**
 * Hook in and add a metabox that displays Subtitle
 */
function nda_register_subtitle_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_nda_';

	/**
	 * Metabox to be displayed on a single page ID
	 */
	$cmb_subtitle = new_cmb2_box( array(
		'id'           => $prefix . 'subtitle_metabox',
		'title'        => __( 'Subtitle', 'cmb2' ),
		'object_types' => array( 'page','post' ), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => false, // Show field names on the left
	) );

	$cmb_subtitle->add_field( array(
		'name' => __( 'Subtitle', 'cmb2' ),
		'id'   => $prefix . 'subtitle',
		'type' => 'text',
	) );
}


add_action( 'cmb2_init', 'yourprefix_register_repeatable_group_field_metabox' );
/**
 * Hook in and add a metabox to demonstrate repeatable grouped fields
 */
function yourprefix_register_repeatable_group_field_metabox() {
	// Start with an underscore to hide fields from custom fields list
	$prefix = '_nda_stats_';
	/**
	 * Repeatable Field Groups
	 */
	$cmb_stats = new_cmb2_box( array(
		'id'           => $prefix . 'metabox',
		'title'        => __( 'Stats', 'cmb2' ),
		'object_types' => array( 'page', ),
		'show_on'      => array( 'key' => 'front-page', 'value' => '', ), // Specific post IDs to display this metabox
	) );
	$cmb_stats->add_field( array(
		'name' => __( 'Title', 'cmb2' ),
		'id'   => $prefix . 'title',
		'type' => 'text',
	) );

	$cmb_stats->add_field( array(
		'name' => __( 'Description', 'cmb2' ),
		'id'   => $prefix . 'copy',
		'type' => 'textarea_small',
	) );


	// $group_field_id is the field id string, so in this case: $prefix . 'demo'
	$group_stats_id = $cmb_stats->add_field( array(
		'id'          => $prefix . 'stat',
		'type'        => 'group',
		//'description' => __( 'Generates reusable form entries', 'cmb2' ),
		'options'     => array(
			'group_title'   => __( 'Stat {#}', 'cmb2' ), // {#} gets replaced by row number
			'add_button'    => __( 'Add Another Stat', 'cmb2' ),
			'remove_button' => __( 'Remove Stat', 'cmb2' ),
			'sortable'      => true, // beta
		),
	) );
	/**
	 * Group fields works the same, except ids only need
	 * to be unique to the group. Prefix is not needed.
	 *
	 * The parent field's id needs to be passed as the first argument.
	 */
	$cmb_stats->add_group_field( $group_stats_id, array(
		'name' => 'Icon',
		'id'   => 's_ico',
		'type' => 'text_small',
		// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );
	$cmb_stats->add_group_field( $group_stats_id, array(
		'name' => 'Stat Title',
		'id'   => 's_title',
		'type' => 'text',
		// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );
	$cmb_stats->add_group_field( $group_stats_id, array(
		'name' => 'Description',
		'description' => 'Write a short description for this Stat',
		'id'   => 's_copy',
		'type' => 'textarea_small',
	) );
}







add_action( 'cmb2_init', 'nda_register_property_links_metabox' );
/**
 * Hook in and add a metabox that only appears on the 'About' page
 */
function nda_register_property_links_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_nda_';

	/**
	 * Metabox to be displayed on a single page ID
	 */
	$cmb_property_links = new_cmb2_box( array(
		'id'           => $prefix . 'property_links',
		'title'        => __( 'Attached Documents', 'cmb2' ),
		'object_types' => array( 'post', ), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );

	$cmb_property_links->add_field( array(
	    'name'    => 'Marketing Package',
	    //'desc'    => '',
	    'id'      => $prefix . 'marketing_dlm',
	    'type'    => 'pw_select',
	    'options' => cmb2_get_dlm_options(
	    	array(
	    	'post_type' => 'dlm_download',
	    	'numberposts' => -1,
		    'tax_query' => array(
		        array(
		            'taxonomy' => 'dlm_download_category',
		            'field'    => 'id',
		            'terms'    => array(27),
		            'operator' => 'NOT IN',
		        ),
		    ),
	    )),
	    'after_field' => '<a href="#" style="margin-left: 20px;" class="button insert-download dlm_insert_download" data-editor="content" title="Insert Download">Quick Add</a><p class="cmb2-metabox-description">Use dropdown to select from Downloads. If a download has not yet been added, you may use Quick Add button, once complete, save and refresh this page to see the new downloads added to the dropdown menu.</p>',
	) );

	$cmb_property_links->add_field( array(
		'name' => __( 'Due Diligence', 'cmb2' ),
		'id'   => $prefix . 'diligence',
		'type' => 'file',
	) );

	$cmb_property_links->add_field( array(
		'name' => __( 'Marketing Package', 'cmb2' ),
		'desc'    => 'OLD',
		'id'   => $prefix . 'mpack',
		'type' => 'file',
	) );

	$cmb_property_links->add_field( array(
		'name' => __( 'Get Financing', 'cmb2' ),
		'id'   => $prefix . 'financing',
		'type' => 'text_url',
	) );

	$cmb_property_links->add_field( array(
		'name' => __( 'Make an Offer', 'cmb2' ),
		'id'   => $prefix . 'offer',
		'type' => 'text_url',
	) );
}




add_action( 'cmb2_init', 'nda_register_property_location_metabox' );
/**
 * Hook in and add a metabox that only appears on the 'About' page
 */
function nda_register_property_location_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_nda_';

	/**
	 * Metabox to be displayed on a single page ID
	 */
	$cmb_property_location = new_cmb2_box( array(
		'id'           => $prefix . 'property_address',
		'title'        => __( 'Property Location', 'cmb2' ),
		'object_types' => array( 'post', ), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );

	$cmb_property_location->add_field( array(
		'name' => __( 'Address 1', 'cmb' ),
		'before_field' => '<p><label>Address 1</label></p>',
		'desc' => __( 'Use abbreviations, ie: Ave, St', 'cmb' ),
		'id'   => $prefix . 'address_1',
		'type' => 'text',
		'before_row' => '<style type="text/css">#property-address .cmb-td .cmb-row {padding-bottom:0;border-bottom:0;}</style><div id="property-address" class="cmb-row cmb-type-address cmb2-id--nda-address"><div class="cmb-th"><label>Property Address</label></div><div class="cmb-td">',
		'show_names'   => false,

	) );
	$cmb_property_location->add_field( array(
		'name' => __( 'Address 2', 'cmb' ),
		'before_field' => '<p><label>Address 2</label></p>',
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'address_2',
		'type' => 'text',
		'show_names'   => false,
	) );
	$cmb_property_location->add_field( array(
		'name' => __( 'City', 'cmb' ),
		'before_field' => '<p><label>City</label></p>',
		'id'   => $prefix . 'city',
		'type' => 'text_medium',
		'default' => 'Brooklyn',
		'show_names'   => false,
		'before_row' => '<div class="alignleft">',
		'after_row' => '</div>',
	) );
	$cmb_property_location->add_field( array(
		'name' => __( 'State', 'cmb' ),
		'before_field' => '<p><label>State</label></p>',
		'id'   => $prefix . 'state',
		'type' => 'text_small',
		'default' => 'NY',
		'show_names'   => false,
		'before_row' => '<div class="alignleft">',
		'after_row' => '</div>',

	) );
	$cmb_property_location->add_field( array(
		'name' => __( 'Zip', 'cmb' ),
		'before_field' => '<p><label>Zip</label></p>',
		'id'   => $prefix . 'zip',
		'type' => 'text_small',
		'before_row' => '<div class="alignleft">',
		'after_row' => '</div></div></div>',
		'show_names'   => false,
	) );

	$cmb_property_location->add_field( array(
		'name' => __( 'Neighborhood', 'cmb2' ),
		'desc' => __( 'ie: "Bushwick", omit city/zip', 'cmb' ),
		'id'   => $prefix . 'neighborhood',
		'type' => 'text',
	) );
}


add_action( 'cmb2_init', 'nda_register_property_details_metabox' );
/**
 * Hook in and add a metabox that only appears on the 'About' page
 */
function nda_register_property_details_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_nda_';

	/**
	 * Metabox to be displayed on a single page ID
	 */
	$cmb_property_details = new_cmb2_box( array(
		'id'           => $prefix . 'property_details',
		'title'        => __( 'Property Details', 'cmb2' ),
		'object_types' => array( 'post', ), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );

	$cmb_property_details->add_field( array(
		'name' => __( 'Gross SF', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'gross_sf',
		'type' => 'text_small',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Units', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'units',
		'type' => 'text_small',
        'attributes' => array(
            'type' => 'number',
            // 'onkeypress' => 'validate(event)'
        ),
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Sub-type', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'subtype',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Price', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'price',
		'type' => 'text_money',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Gross Rent', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'gross_rent',
		'type' => 'text_money',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'NOI', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'noi',
		'type' => 'text_money',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Cap Rate Current', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'cap_rate_current',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Cap Rate Pro-Forma', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'cap_rate_proforma',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'GRM Current', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'grm_current',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'GRM Pro-Forma', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'grm_proforma',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Price/SqFt', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'ppsft',
		'type' => 'text_money',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Price/Unit', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'ppu',
		'type' => 'text_money',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Building Size', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'building_size',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Lot Size', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'lot_size',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Year Built', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'year_built',
		'type' => 'text_small',
        'attributes' => array(
            'type' => 'number',
            // 'onkeypress' => 'validate(event)'
        ),
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Total Buildable SqFt', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'total_buildable_sqft',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Price / Buildable SqFt', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'price_per_buildable_sqft',
		'type' => 'text_money',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Far', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'far',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Approved Plans', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'approved_plans',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Existing Financing', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'existing_finance',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Status', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'status',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'BID Deadline', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'bid_deadline',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'Renovated', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'renovated',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( 'List to Close Ratio', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'list_to_close_ratio',
		'type' => 'text',
	) );
	$cmb_property_details->add_field( array(
		'name' => __( '# of Offers', 'cmb' ),
		// 'desc' => __( 'field description (optional)', 'cmb' ),
		'id'   => $prefix . 'number_of_offers',
		'type' => 'text_small',
        'attributes' => array(
            'type' => 'number',
            // 'onkeypress' => 'validate(event)'
        ),
	) );
}






add_action( 'cmb2_init', 'nda_register_home_page_metabox' );
/**
 * Hook in and add a metabox that only appears on the 'About' page
 */
function nda_register_home_page_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_nda_home_';

	/**
	 * Metabox to be displayed on a single page ID
	 */
	$cmb_home_page = new_cmb2_box( array(
		'id'           => $prefix . 'metabox',
		'title'        => __( 'Site Settings', 'cmb2' ),
		'object_types' => array( 'page', ), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		'show_on_cb'      => 'nda_show_if_front_page'
	) );

	$cmb_home_page->add_field( array(
		'name' => __( 'Logo Image', 'cmb2' ),
		'id'   => $prefix . 'logo',
		'type' => 'file',
	) );

}




add_action( 'cmb2_init', 'nda_register_featured_metabox' );
/**
 * Hook in and add a metabox that only appears on the 'About' page
 */
function nda_register_featured_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_nda_featured_';

	/**
	 * Metabox to be displayed on a single page ID
	 */
	$cmb_featured = new_cmb2_box( array(
		'id'           => $prefix . 'metabox',
		'title'        => __( 'Featured Brokers', 'cmb2' ),
		'object_types' => array( 'page' ), // Post type
		//'show_on'      => array( 'key' => 'page-template', 'value' => array( 'template-standard.php', ), ), // Specific post IDs to display this metabox
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => false, // Show field names on the left
	) );

	$cmb_featured->add_field( array(
	    'name'    => 'Featured Agents',
	    'desc'    => 'Click and start typing an agents name (optional)',
	    'id'      => $prefix . 'agents',
	    'type'    => 'pw_multiselect',
	    'options' => cmb2_get_user_options( array( 'fields' => array( 'user_nicename' ), 'role' => 'admin', ) ),
	) );
/*
	$cmb_featured->add_field( array(
	    'name'    => __( 'Select2', 'tad_cmb2' ),
	    'desc'    => __( 'Type some letters to have select2 autocomplete kick in!', 'cmb2' ),
	    'id'      => $prefix . 'brokers',
	    'type'    => 'pw_multiselect',
	    'options' => cmb2_get_user_options( array( 'fields' => array( 'user_nicename' ), 'role' => 'admin', ) ),
	) );
*/

}



add_action( 'cmb2_init', 'nda_register_listing_metabox' );
/**
 * Hook in and add a metabox that only appears on the 'About' page
 */
function nda_register_listing_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_nda_listing_';

	/**
	 * Metabox to be displayed on a single page ID
	 */
	$cmb_listing = new_cmb2_box( array(
		'id'           => $prefix . 'metabox',
		'title'        => __( 'Property Brokers', 'cmb2' ),
		'object_types' => array( 'post' ), // Post type
		//'show_on'      => array( 'key' => 'page-template', 'value' => array( 'template-standard.php', ), ), // Specific post IDs to display this metabox
		'context'      => 'normal', //  'normal', 'advanced', or 'side'
		'priority'     => 'default', //  'high', 'core', 'default' or 'low'
		'show_names'   => false, // Show field names on the left
	) );

	$cmb_listing->add_field( array(
	    'name'    => 'Featured Agents',
	    'desc'    => 'Click and start typing to populate smart search.',
	    'id'      => $prefix . 'brokers',
	    'type'    => 'pw_multiselect',
	    'options' => cmb2_get_user_options( array( 'fields' => array( 'user_nicename' ), 'role' => 'admin', ) ),
	) );

}



add_action( 'cmb2_init', 'nda_register_cta_metabox' );
/**
 * Hook in and add a metabox that only appears on the 'About' page
 */
function nda_register_cta_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_nda_cta_';

	/**
	 * Metabox to be displayed on a single page ID
	 */
	$cmb_cta = new_cmb2_box( array(
		'id'           => $prefix . 'metabox',
		'title'        => __( 'Call To Action Box (optional)', 'cmb2' ),
		'object_types' => array( 'service', 'page' ), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		'show_on_cb'  => 'nda_hide_if_contact_page',
	) );

	$cmb_cta->add_field( array(
	    'name'    => 'Headline',
	    'id'      => $prefix . 'headline',
	    'type'    => 'text'
	) );

	$cmb_cta->add_field( array(
	    'name' => 'Copy',
	    'id' => $prefix . 'copy',
	    'type' => 'textarea_small'
	) );

	$cmb_cta->add_field( array(
	    'name' => __( 'URL', 'cmb' ),
	    'id'   => $prefix . 'url',
	    'type' => 'text_url',
	    // 'protocols' => array( 'http', 'https', 'ftp', 'ftps', 'mailto', 'news', 'irc', 'gopher', 'nntp', 'feed', 'telnet' ), // Array of allowed protocols
	) );

	$cmb_cta->add_field( array(
	    'name'    => 'Button Label',
	    'default' => 'Learn More',
	    'id'      => $prefix . 'btn',
	    'type'    => 'text_small'
	) );

}




add_action( 'cmb2_init', 'nda_register_about_page_metabox' );
/**
 * Hook in and add a metabox that only appears on the 'About' page
 */
function nda_register_about_page_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_nda_about_';

	/**
	 * Metabox to be displayed on a single page ID
	 */
	$cmb_about_page = new_cmb2_box( array(
		'id'           => $prefix . 'metabox',
		'title'        => __( 'About Page Metabox', 'cmb2' ),
		'object_types' => array( 'page', ), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	$cmb_about_page->add_field( array(
		'name' => __( 'Test Text', 'cmb2' ),
		'desc' => __( 'field description (optional)', 'cmb2' ),
		'id'   => $prefix . 'test_text',
		'type' => 'text',
	) );

}




add_action( 'cmb2_init', 'nda_register_repeatable_group_field_metabox' );
/**
 * Hook in and add a metabox to demonstrate repeatable grouped fields
 */
function nda_register_repeatable_group_field_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_nda_';

	/**
	 * Repeatable Field Groups
	 */
	$cmb_timeline = new_cmb2_box( array(
		'id'           => $prefix . 'timeline',
		'title'        => __( 'Transaction Timeline', 'cmb2' ),
		'object_types' => array( 'page', ),
		'show_on'      => array( 'key' => 'page-template', 'value' => array( 'template-approach.php', ), ), // Specific post IDs to display this metabox
	) );

	// $milestone_field_id is the field id string, so in this case: $prefix . 'demo'
	$milestone_field_id = $cmb_timeline->add_field( array(
		'id'          => $prefix . 'repeat_milestone',
		'type'        => 'group',
		'description' => __( 'Generates reusable form entries', 'cmb2' ),
		'options'     => array(
			'group_title'   => __( 'Milestone {#}', 'cmb2' ), // {#} gets replaced by row number
			'add_button'    => __( 'Add Another Milestone', 'cmb2' ),
			'remove_button' => __( 'Remove Milestone', 'cmb2' ),
			'sortable'      => true, // beta
		),
	) );

	/**
	 * Group fields works the same, except ids only need
	 * to be unique to the group. Prefix is not needed.
	 *
	 * The parent field's id needs to be passed as the first argument.
	 */
	$cmb_timeline->add_group_field( $milestone_field_id, array(
		'name'       => __( 'Milestone Title', 'cmb2' ),
		'id'         => 'm_title',
		'type'       => 'text',
		// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );

	$cmb_timeline->add_group_field( $milestone_field_id, array(
		'name' => __( 'Icon', 'cmb2' ),
		'id'   => 'm_ico',
		'type' => 'text_small',
	) );

	$cmb_timeline->add_group_field( $milestone_field_id, array(
		'name' => __( 'Days', 'cmb2' ),
		'description' => __( 'ie: "Day 1 - 10"', 'cmb2' ),
		'id'   => 'm_days',
		'type' => 'text_small',
	) );

	$cmb_timeline->add_group_field( $milestone_field_id, array(
		'name'        => __( 'Description', 'cmb2' ),
		'description' => __( 'Write a short description for this entry', 'cmb2' ),
		'id'          => 'm_copy',
		'type'        => 'textarea_small',
	) );

}











add_action( 'cmb2_init', 'nda_register_user_profile_metabox' );
/**
 * Hook in and add a metabox to add fields to the user profile pages
 */
function nda_register_user_profile_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_nda_';

	/**
	 * Metabox for the user profile screen
	 */
	$cmb_user = new_cmb2_box( array(
		'id'               => $prefix . 'edit',
		'title'            => __( 'User Profile Metabox', 'cmb2' ),
		'object_types'     => array( 'user' ), // Tells CMB2 to use user_meta vs post_meta
		'show_names'       => true,
		'new_user_section' => 'add-new-user', // where form will show on new user page. 'add-existing-user' is only other valid option.
	) );

	$cmb_user->add_field( array(
		'name'     => __( 'Extra Info', 'cmb2' ),
		'id'       => $prefix . 'extra_info',
		'type'     => 'title',
		'on_front' => false,
	) );

	$cmb_user->add_field( array(
		'name'    => __( 'Avatar', 'cmb2' ),
		'id'      => $prefix . 'user_avatar',
		'type'    => 'file',
	) );

	$cmb_user->add_field( array(
		'name' => __( 'Job Title', 'cmb2' ),
		'id'   => $prefix . 'job_title',
		'type' => 'text',
	) );

	$cmb_user->add_field( array(
		'name' => __( 'LIC', 'cmb2' ),
		'id'   => $prefix . 'lic',
		'type' => 'text',
	) );

	$cmb_user->add_field( array(
		'name' => __( 'Company', 'cmb2' ),
		'id'   => $prefix . 'user_company',
		'type' => 'text',
	) );

	$cmb_user->add_field( array(
		'name' => __( 'Work Phone', 'cmb2' ),
		'id'   => $prefix . 'work_phone',
		'type' => 'text',
	) );

	$cmb_user->add_field( array(
		'name' => __( 'Twitter URL', 'cmb2' ),
		'id'   => $prefix . 'user_twitterurl',
		'type' => 'text_url',
	) );

	$cmb_user->add_field( array(
		'name' => __( 'Linkedin URL', 'cmb2' ),
		'id'   => $prefix . 'user_linkedinurl',
		'type' => 'text_url',
	) );

/*
	$cmb_user->add_field( array(
		'name' => __( 'User Field', 'cmb2' ),
		'desc' => __( 'field description (optional)', 'cmb2' ),
		'id'   => $prefix . 'user_text_field',
		'type' => 'text',
	) );
*/

}

add_action( 'cmb2_init', 'nda_register_theme_options_metabox' );
/**
 * Hook in and register a metabox to handle a theme options page
 */
function nda_register_theme_options_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$option_key = '_nda_theme_options';

	/**
	 * Metabox for an options page. Will not be added automatically, but needs to be called with
	 * the `cmb2_metabox_form` helper function. See wiki for more info.
	 */
	$cmb_options = new_cmb2_box( array(
		'id'      => $option_key . 'page',
		'title'   => __( 'Theme Options Metabox', 'cmb2' ),
		'hookup'  => false, // Do not need the normal user/post hookup
		'show_on' => array(
			// These are important, don't remove
			'key'   => 'options-page',
			'value' => array( $option_key )
		),
	) );

	/**
	 * Options fields ids only need
	 * to be unique within this option group.
	 * Prefix is not needed.
	 */
	$cmb_options->add_field( array(
		'name'    => __( 'Site Background Color', 'cmb2' ),
		'desc'    => __( 'field description (optional)', 'cmb2' ),
		'id'      => 'bg_color',
		'type'    => 'colorpicker',
		'default' => '#ffffff',
	) );
}