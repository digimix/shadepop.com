<?php

namespace Roots\Sage\Extras;

use Roots\Sage\Config;



require_once locate_template('/bower_components/wp-bootstrap-navwalker/wp_bootstrap_navwalker.php');
//require_once locate_template('/lib/post-types/report.php');
require_once locate_template('/lib/post-types/service.php');
require_once locate_template('/lib/taxonomy.php');

//include_once locate_template('inc/property-brokers/property-brokers.php'); // Brokers: Creates meta boxes


// retrieves the attachment ID from the file URL
/*
function get_image_id($image_url) {
	global $wpdb;
	$attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE guid='%s';", $image_url ));
        return $attachment[0];
}
*/

add_action('init', __NAMESPACE__ . '\\remove_editor_init');
function remove_editor_init() {
    global $post;

    if ( 'page' == get_option( 'show_on_front' ) )
        remove_post_type_support('page', 'editor');

}


function get_image_id( $url ) {
    global $wpdb;

    $dir = wp_upload_dir();
    $path = $url;

    if ( 0 === strpos( $path, $dir['baseurl'] . '/' ) ) {
        $path = substr( $path, strlen( $dir['baseurl'] . '/' ) );
    }

    $sql = $wpdb->prepare(
        "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_wp_attached_file' AND meta_value = %s",
        $path
    );
    $post_id = $wpdb->get_var( $sql );
    if ( ! empty( $post_id ) ) {
        return (int) $post_id;
    }
}


function removeGetVariable($string, $key) {

    parse_str($string, $variables);

    unset($variables[$key]);

    return http_build_query($variables);

}



add_action( 'init', __NAMESPACE__ . '\\my_custom_init' );
function my_custom_init() {
	remove_post_type_support( 'dlm_download', 'custom-fields' );
	remove_post_type_support( 'dlm_download', 'editor' );
}


if ( ! class_exists( 'cmb_Meta_Box' ) ) {
	require_once locate_template('/lib/metabox.php');
	require_once locate_template('/bower_components/CMB2-Snippet-Library/custom-field-types/address-field-type.php');
}



function no_mo_adminbar() {
	// Remove admin bar for Subscribers
	get_currentuserinfo();
	global $user_level;
	if ($user_level <= 1) {
	     show_admin_bar(false);
	}
}
add_action('after_setup_theme', __NAMESPACE__ . '\\no_mo_adminbar');


function check_for_input($array, $filter){
     foreach($array as $key=>$value){
           if($value !== "" && in_array($key, $filter)){
                return true;
           }
     }
     return false;
}

function mix_change_post_label() {
    global $menu;
    global $submenu;
    $menu[5][0] = 'Listings';
    $submenu['edit.php'][5][0] = 'Listings';
    $submenu['edit.php'][10][0] = 'Add Listings';
    $submenu['edit.php'][16][0] = 'Listing Tags';
    echo '';
}
add_action( 'admin_menu', __NAMESPACE__ . '\\mix_change_post_label' );


function mix_change_post_object() {
    global $wp_post_types;
    $labels = &$wp_post_types['post']->labels;
    $labels->name = 'Listings';
    $labels->singular_name = 'Listing';
    $labels->add_new = 'Add New Listing';
    $labels->add_new_item = 'Add New Listing';
    $labels->edit_item = 'Edit Listing';
    $labels->new_item = 'Listing';
    $labels->view_item = 'View Listing';
    $labels->search_items = 'Search Listings';
    $labels->not_found = 'No Listings found';
    $labels->not_found_in_trash = 'No Listings found in Trash';
    $labels->all_items = 'All Listings';
    $labels->menu_name = 'Listings';
    $labels->name_admin_bar = 'Listings';
}

add_action( 'init', __NAMESPACE__ . '\\mix_change_post_object' );



function hwl_home_pagesize( $query ) {
    if ( is_admin() || ! $query->is_main_query() )
        return;

    if ( is_home() ) {
        // Display only 1 post for the original blog archive
        $query->set( 'posts_per_page', 1 );
        return;
    }

    if ( is_category() ) {
        // Display 50 posts for a custom post type called 'movie'
        $query->set( 'posts_per_page', -1 );
        return;
    }

}
add_action( 'pre_get_posts', __NAMESPACE__ . '\\hwl_home_pagesize', 1 );



function wtnerd_edition_specific_categories() {
/*
    add_rewrite_rule( '(.+?)/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$', '?category_name=$matches[1]&district=$matches[2]&feed=$matches[3]', 'top' );
    add_rewrite_rule( '(.+?)/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$', '?category_name=$matches[1]&district=$matches[2]&feed=$matches[3]', 'top' );
    add_rewrite_rule( '(.+?)/category/(.+?)/page/?([0-9]{1,})/?$', '?category_name=$matches[1]&district=$matches[2]&paged=$matches[3]', 'top' );
    add_rewrite_rule( '(.+?)/category/(.+?)/?$', '?category_name=$matches[1]&district=$matches[2]', 'top' );

    add_rewrite_rule( '(.+?)/section/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$', '?category_name=$matches[1]&tag=$matches[2]&feed=$matches[3]', 'top' );
    add_rewrite_rule( '(.+?)/section/(.+?)/(feed|rdf|rss|rss2|atom)/?$', '?category_name=$matches[1]&tag=$matches[2]&feed=$matches[3]', 'top' );
    add_rewrite_rule( '(.+?)/section/(.+?)/page/?([0-9]{1,})/?$', '?category_name=$matches[1]&tag=$matches[2]&paged=$matches[3]', 'top' );
    add_rewrite_rule( '(.+?)/section/(.+?)/?$', '?category_name=$matches[1]&tag=$matches[2]', 'top' );
*/

	add_rewrite_rule( 'category/(.+?)/([^/]+)/?', 'index.php?category_name=$matches[1]&district=$matches[2]', 'top' );

	flush_rewrite_rules();
}
add_action( 'init',  __NAMESPACE__ . '\\wtnerd_edition_specific_categories' );


/**
 * Hide editor on specific pages.
 *
 */
/*
add_action( 'admin_init', __NAMESPACE__ . '\\hide_editor' );

function hide_editor() {
  // Get the Post ID.
  $post_id = $_GET['post'] ? $_GET['post'] : $_POST['post_ID'] ;
  if( !isset( $post_id ) ) return;

  // Hide the editor on the page titled 'Homepage'
  $homepgname = get_the_title($post_id);
  if($homepgname == 'The Riney Team'){
    remove_post_type_support('page', 'editor');
  }

  // Hide the editor on a page with a specific page template
  // Get the name of the Page Template file.
  $template_file = get_post_meta($post_id, '_wp_page_template', true);

  if($template_file == 'front-page.php'){ // the filename of the page template
    remove_post_type_support('page', 'editor');
  }
}
*/


function max_meta_value(){
    global $wpdb;
    //$_nda_price = preg_replace('/[\$,]/', '', $_GET['_nda_price']);
    $query = "SELECT max(cast(meta_value as UNSIGNED)) FROM wp_postmeta WHERE $wpdb->postmeta.meta_key='_nda_price'";
    $the_max = $wpdb->get_var($query);
    // $the_max = str_replace(",", "",$the_max);
    return $the_max;
}

function min_meta_value(){
    global $wpdb;
    //$price = preg_replace('/[\$,]/', '', $_GET['_nda_price']);
    $query = "SELECT min(cast(meta_value as UNSIGNED)) FROM wp_postmeta WHERE meta_key='_nda_price'";
    $the_min = $wpdb->get_var($query);
    if (!is_numeric($the_min)) {
	    $the_min = 0;
    }
    return $the_min;
}

function sanitize_price($value) {
	$value = preg_replace('/[\$,]/', '', $value);
	return $value;
}

// GET THE FIRST IMAGE
function catch_that_image() {
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
  if (isset($matches[1][0])){
    $first_img = $matches[1][0];
  }
  if(empty($first_img)){ //Defines a default image
    $first_img = get_template_directory_uri() . "/images/noimage.jpg";
  }
  return $first_img;
}

// Logic to get the correct image size
function featured_url($size){
  global $post, $posts;
  $image = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), $size );
  if (has_post_thumbnail()){
    $url = $image['0'];
  } else {
    $url = catch_that_image();
  }
    return $url;
}


// Logic to get the correct image size
function featured_url_by_id($id, $size){
  global $post, $posts;
  $image = wp_get_attachment_image_src( $id, $size );
  $url = $image['0'];
    return $url;
}



/**
 * Add <body> classes
 */
function body_class($classes) {
  // Add page slug if it doesn't exist
  if (is_single() || is_page() && !is_front_page()) {
    if (!in_array(basename(get_permalink()), $classes)) {
      $classes[] = basename(get_permalink());
    }
  }

  // Add class if sidebar is active
  if (Config\display_sidebar()) {
    $classes[] = 'sidebar-primary';
  }

  return $classes;
}
add_filter('body_class', __NAMESPACE__ . '\\body_class');

/**
 * Clean up the_excerpt()
 */
function excerpt_more() {
  return ' &hellip; <a href="' . get_permalink() . '">' . __('Continued', 'sage') . '</a>';
}
add_filter('excerpt_more', __NAMESPACE__ . '\\excerpt_more');




// Disable support for comments and trackbacks in post types
function df_disable_comments_post_types_support() {
	$post_types = get_post_types();
	foreach ($post_types as $post_type) {
		if(post_type_supports($post_type, 'comments')) {
			remove_post_type_support($post_type, 'comments');
			remove_post_type_support($post_type, 'trackbacks');
		}
	}
}
add_action('admin_init', __NAMESPACE__ . '\\df_disable_comments_post_types_support');

// Close comments on the front-end
function df_disable_comments_status() {
	return false;
}
add_filter('comments_open', __NAMESPACE__ . '\\df_disable_comments_status', 20, 2);
add_filter('pings_open', __NAMESPACE__ . '\\df_disable_comments_status', 20, 2);

// Hide existing comments
function df_disable_comments_hide_existing_comments($comments) {
	$comments = array();
	return $comments;
}
add_filter('comments_array', __NAMESPACE__ . '\\df_disable_comments_hide_existing_comments', 10, 2);

// Remove comments page in menu
function df_disable_comments_admin_menu() {
	remove_menu_page('edit-comments.php');
}
add_action('admin_menu', __NAMESPACE__ . '\\df_disable_comments_admin_menu');

// Redirect any user trying to access comments page
function df_disable_comments_admin_menu_redirect() {
	global $pagenow;
	if ($pagenow === 'edit-comments.php') {
		wp_redirect(admin_url()); exit;
	}
}
add_action('admin_init', __NAMESPACE__ . '\\df_disable_comments_admin_menu_redirect');

// Remove comments metabox from dashboard
function df_disable_comments_dashboard() {
	remove_meta_box('dashboard_recent_comments', 'dashboard', 'normal');
}
add_action('admin_init', __NAMESPACE__ . '\\df_disable_comments_dashboard');

// Remove comments links from admin bar
function df_disable_comments_admin_bar() {
	if (is_admin_bar_showing()) {
		remove_action('admin_bar_menu', 'wp_admin_bar_comments_menu', 60);
	}
}
add_action('init', __NAMESPACE__ . '\\df_disable_comments_admin_bar');


/*

add_action('admin_init', __NAMESPACE__ . '\\deleteCommaDB');
function deleteCommaDB(){
	// global $wp_locale;
	// $search = array( $wp_locale->number_format['thousands_sep'], $wp_locale->number_format['decimal_point'] );
	// $replace = array( '', '.' );

    // The Query
    $args = array ( 'posts_per_page' => -1 );
    $the_query = new WP_Query( $args );

    // The Loop
    while ( $the_query->have_posts() ) :
        $the_query->the_post();

		$prefix = '_nda_';
		$price_key = '_nda_listing_brokers';
		$nda_brokers_json = get_post_meta( get_the_ID(), '_nda_brokers', true );
		$newPrice = json_decode($nda_brokers_json);

        //$price_key = $prefix . 'neighborhood';
        //$getPrice = get_post_meta( get_the_ID(), $price_key, true);
		// $newPrice = str_replace(array('$', ','), '', $getPrice);
		//$newPrice = number_format_i18n( (float) str_ireplace( $search, $replace, $getPrice ), 2 );

        update_post_meta(get_the_ID(), $price_key, $newPrice);

    endwhile;
}
*/