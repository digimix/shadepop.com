<?php
/*
Template Name: Contact
*/

while (have_posts()) : the_post();

$company = get_post_meta( $post->ID, '_nda_company', true );
$lead = get_post_meta( $post->ID, '_nda_leader', true );
$street = get_post_meta( $post->ID, '_nda_street', true );
$city = get_post_meta( $post->ID, '_nda_city', true );
$state = get_post_meta( $post->ID, '_nda_state', true );
$zip = get_post_meta( $post->ID, '_nda_zip', true );
$phone = get_post_meta( $post->ID, '_nda_phone', true );
$email = get_post_meta( $post->ID, '_nda_email', true );
$fax = get_post_meta( $post->ID, '_nda_fax', true );
$gmap = get_post_meta( $post->ID, '_nda_gmap_iframe', true );
$thumb_id = get_post_thumbnail_id();
$thumb_url = wp_get_attachment_image_src($thumb_id,'large', true);
$slide_img = $thumb_url[0];
$subtitle = get_post_meta(get_the_id(), '_nda_subtitle', true);
$offices = get_post_meta(get_the_id(), '_nda_offices_group', 1);

get_template_part('templates/page', 'header');
?>
<div class="container">
	<ul class="col-2">
		<?php
		$i=0; foreach ( (array) $offices as $key => $office ) {
		    // $img = $title = $desc = $caption = '';

		    if ( isset( $office['title'] ) )
		        $title = esc_html( $office['title'] );

		    if ( isset( $office['phone'] ) )
		        $phone = esc_html( $office['phone'] );

		    if ( isset( $office['address'] ) )

				$address = $office['address'];

				// Set default values for each address key
				$address = wp_parse_args( $address, array(
				    'address-1' => '',
				    'address-2' => '',
				    'city'      => '',
				    'state'     => '',
				    'zip'       => '',
				) );


		    if ( isset( $office['phone_direct'] ) )
		        $phone_direct = $office['phone_direct'];

		    if ( isset( $office['email'] ) )
		        $email = esc_html($office['email']);

		    if ( isset( $office['lead'] ) )
		        $lead = esc_html($office['lead']);
		        $user_info = get_userdata($lead);

		        $i++;
			?>
			<li class="office shaded-light <?= ($i%2 ? 'odd':'even'); ?>">
				<div class="header">
					<h4 class="beta caps m0 "><?= $title;?></h4>
				</div>
				<div class="content">
					<h3 class="caps">
						<a href="<?= get_author_posts_url( $user_info->ID ); ?>">
							<?= $user_info->first_name . ' ' .  $user_info->last_name; ?>
						</a>
					</h3>
					<p id="address-<?= ($i%2 ? '1':'2'); ?>"><i class="fa fa-map-marker"></i><?= esc_html( $address['address-1'] ); ?>
					<?php if ( $address['address-2'] ) : ?>
					    <br/><?= esc_html( $address['address-2'] ); ?>
					<?php endif; ?>
					<br/><?= esc_html( $address['city'] ) . ', ' . esc_html( $address['state'] ) . ' '  . esc_html( $address['zip'] ); ?></p>
					<label for="address-<?= ($i%2 ? '1':'2'); ?>">Address</label>
					<p id="p-main-<?= ($i%2 ? '1':'2'); ?>"><i class="fa fa-phone"></i> <?= $phone; ?></p><label for="p-main-<?= ($i%2 ? '1':'2'); ?>">Main</label>
					<p id="p-direct-<?= ($i%2 ? '1':'2'); ?>"><i class="fa fa-phone"></i> <?= $phone_direct; ?></p><label for="p-direct-<?= ($i%2 ? '1':'2'); ?>">Direct</label>
					<p id="email-<?= ($i%2 ? '1':'2'); ?>"><i class="fa fa-envelope-o"></i> <?= $email; ?></p>
					<label for="email-<?= ($i%2 ? '1':'2'); ?>">Email</label>
					<!-- <p>Email the lead:<br/> <a href="mailto:<?= get_the_author_meta( 'user_email', $user_info->ID ); ?>"><?php the_author_meta( 'display_name', $user_info->ID ); ?></a></p> -->
				</div>
			</li>
		<?php } ?>
	</ul>
</div>

<!--
<div class="row">
	<div class="col-sm-12">
	<div class="container serif" style="padding-top:5%;padding-bottom:5%;">
		<div class="serif">
		<?php the_content(); ?>
		</div>
	</div>
	</div>
</div>
-->

	<?php get_template_part('templates/content-agents'); ?>

	<?php get_template_part('templates/content-cta'); ?>


<section>
	<div class="section-header">
		<div class="container">
			<h4>Request a Call Back</h4>
		</div>
	</div>
	<div class="section-content gradient">
		<div class="container" style="padding-top:40px;padding-bottom: 20px;">
			<?= do_shortcode( '[contact-form-7 id="2051" title="contact_horiz"]' ) ?>
		</div>
	</div>
</section>

<div class="page-end"> </div>

<?php endwhile; ?>