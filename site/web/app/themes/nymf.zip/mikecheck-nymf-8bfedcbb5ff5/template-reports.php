<?php
/**
 * Template Name: Reports Template
 */
  use Roots\Sage\Extras;
?>

<?php while (have_posts()) : the_post(); ?>

	<?php get_template_part('templates/page', 'header'); ?>
	<section class="banner" style="background:url(  <?= Extras\featured_url('large'); ?>);"></section>

	<?php get_template_part('templates/content', 'page'); ?>
<?php endwhile; ?>

<section>
	<div class="container">
		<ul class="sales-report col-4">
		<?php

		$args = array( 'posts_per_page' => -1, 'post_type' => 'dlm_download', 'dlm_download_category' => 'reports' );

		$myposts = get_posts( $args );
		foreach ( $myposts as $post ) : setup_postdata( $post ); global $dlm_download; ?>

			<li>
				<a class="download-link" title="<?php $dlm_download->the_title(); if ( $dlm_download->has_version_number() ) printf( __( 'Version %s', 'download_monitor' ), $dlm_download->get_the_version_number() ); ?>" href="<?php $dlm_download->the_download_link(); ?>" rel="nofollow">
					<figure>
						<?php //the_post_thumbnail('large', array('class'=>'img-responsive')); ?>
						<img src="<?= Extras\featured_url(['353', '99999']); ?>" class="img-responsive">
					</figure>
				</a>
			</li>
		<?php endforeach;
		wp_reset_postdata();

		?>
		</ul>
	</div>
</section>

	<?php get_template_part('templates/content-agents'); ?>

	<?php get_template_part('templates/content-cta'); ?>
